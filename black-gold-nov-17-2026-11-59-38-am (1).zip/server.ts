import express from 'express';
import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'blackgold-db.json');

const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

interface StoredUser {
  id: string;
  handle: string;
  displayName: string;
  bio: string;
  dpUrl: string;
  age: number;
  gender: 'woman' | 'man' | 'non-binary';
  blackCoins: number;
  goldCoins: number;
  streakDays: number;
  lastDailyClaimAt: string | null;
  totalDailyGoldClaimed: number;
  dinoHighScore: number;
  runnerHighScore: number;
  moderationStatus: 'active' | 'pending_suspension' | 'suspended';
  suspensionReason: string | null;
  suspensionScheduledAt: string | null;
  suspensionDeadlineAt: string | null;
  acceptedTosAt: string;
  acceptedPrivacyAt: string;
  createdAt: string;
}

interface StoredStory {
  id: string;
  userId: string;
  mediaUrl: string;
  caption: string;
  viewerIds: string[];
  createdAt: string;
  expiresAt: string;
}

interface StoredFollow {
  followerId: string;
  followingId: string;
  createdAt: string;
}

interface StoredBlock {
  blockerId: string;
  blockedId: string;
  createdAt: string;
}

interface StoredTransaction {
  id: string;
  userId: string;
  type: 'daily_reward' | 'conversion' | 'p2p_transfer' | 'game_dino' | 'game_runner' | 'story_tip';
  currency: 'black' | 'gold';
  amount: number;
  secondaryCurrency?: 'black' | 'gold';
  secondaryAmount?: number;
  fromUserId?: string;
  fromHandle?: string;
  toUserId?: string;
  toHandle?: string;
  note: string;
  createdAt: string;
}

interface StoredNotification {
  id: string;
  userId: string;
  category: 'transfer' | 'follow' | 'streak' | 'moderation' | 'system';
  title: string;
  body: string;
  read: boolean;
  createdAt: string;
}

interface StoredReport {
  id: string;
  reporterId: string;
  targetUserId: string;
  targetHandle: string;
  category: 'inappropriate_content' | 'harassment' | 'underage_under_12' | 'spam_scam';
  details: string;
  context: 'profile' | 'story' | 'video_call';
  createdAt: string;
}

interface DatabaseSchema {
  users: StoredUser[];
  sessions: Record<string, string>;
  stories: StoredStory[];
  follows: StoredFollow[];
  blocks: StoredBlock[];
  transactions: StoredTransaction[];
  notifications: StoredNotification[];
  reports: StoredReport[];
}

function createSeedDatabase(): DatabaseSchema {
  const now = new Date();
  const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();
  const twoHoursAgo = new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString();
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();

  const users: StoredUser[] = [
    {
      id: 'usr_sophia',
      handle: 'sophia',
      displayName: 'Sophia Laurent',
      bio: 'Creative director in Milan. Gold Runner rank #2 and evening espresso stories.',
      dpUrl: '/src/assets/images/avatar_sophia_1794896683221.jpg',
      age: 24,
      gender: 'woman',
      blackCoins: 14500,
      goldCoins: 3420,
      streakDays: 18,
      lastDailyClaimAt: yesterday,
      totalDailyGoldClaimed: 18000,
      dinoHighScore: 4280,
      runnerHighScore: 1940,
      moderationStatus: 'active',
      suspensionReason: null,
      suspensionScheduledAt: null,
      suspensionDeadlineAt: null,
      acceptedTosAt: yesterday,
      acceptedPrivacyAt: yesterday,
      createdAt: yesterday,
    },
    {
      id: 'usr_marcus',
      handle: 'marcus',
      displayName: 'Marcus Vance',
      bio: 'Arcade strategist & live video host. Always open for clean 1v1 runner tips.',
      dpUrl: '/src/assets/images/avatar_marcus_1794896684056.jpg',
      age: 27,
      gender: 'man',
      blackCoins: 9200,
      goldCoins: 5100,
      streakDays: 42,
      lastDailyClaimAt: yesterday,
      totalDailyGoldClaimed: 42000,
      dinoHighScore: 6150,
      runnerHighScore: 2810,
      moderationStatus: 'active',
      suspensionReason: null,
      suspensionScheduledAt: null,
      suspensionDeadlineAt: null,
      acceptedTosAt: yesterday,
      acceptedPrivacyAt: yesterday,
      createdAt: yesterday,
    },
    {
      id: 'usr_aria',
      handle: 'aria',
      displayName: 'Aria Chen',
      bio: 'Architectural photographer & daily Dino Jump survival grinder.',
      dpUrl: '/src/assets/images/avatar_aria_1794896684243.jpg',
      age: 21,
      gender: 'woman',
      blackCoins: 22000,
      goldCoins: 2650,
      streakDays: 9,
      lastDailyClaimAt: yesterday,
      totalDailyGoldClaimed: 9000,
      dinoHighScore: 8900,
      runnerHighScore: 1520,
      moderationStatus: 'active',
      suspensionReason: null,
      suspensionScheduledAt: null,
      suspensionDeadlineAt: null,
      acceptedTosAt: yesterday,
      acceptedPrivacyAt: yesterday,
      createdAt: yesterday,
    },
  ];

  const stories: StoredStory[] = [
    {
      id: 'str_1',
      userId: 'usr_sophia',
      mediaUrl: '/src/assets/images/story_gold_lounge_1794896685131.jpg',
      caption: 'Morning espresso on the travertine terrace before today’s Gold Runner session.',
      viewerIds: [],
      createdAt: twoHoursAgo,
      expiresAt: in24h,
    },
    {
      id: 'str_2',
      userId: 'usr_marcus',
      mediaUrl: '/src/assets/images/story_arcade_trophy_1794896685241.jpg',
      caption: '42-day streak milestone unlocked. Sending 50 Gold Coins to top Dino survivors.',
      viewerIds: [],
      createdAt: twoHoursAgo,
      expiresAt: in24h,
    },
  ];

  const follows: StoredFollow[] = [
    { followerId: 'usr_sophia', followingId: 'usr_marcus', createdAt: yesterday },
    { followerId: 'usr_marcus', followingId: 'usr_sophia', createdAt: yesterday },
    { followerId: 'usr_aria', followingId: 'usr_sophia', createdAt: yesterday },
  ];

  return {
    users,
    sessions: {},
    stories,
    follows,
    blocks: [],
    transactions: [],
    notifications: [],
    reports: [],
  };
}

function loadDatabase(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_PATH)) {
    const seed = createSeedDatabase();
    writeDatabaseAtomic(seed);
    return seed;
  }
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as DatabaseSchema;
    return parsed;
  } catch {
    const seed = createSeedDatabase();
    writeDatabaseAtomic(seed);
    return seed;
  }
}

function writeDatabaseAtomic(data: DatabaseSchema): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpPath = `${DB_PATH}.${process.pid}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpPath, DB_PATH);
}

const db: DatabaseSchema = loadDatabase();

function saveDb(): void {
  writeDatabaseAtomic(db);
}

function enforcePendingSuspensions(): void {
  const nowMs = Date.now();
  let changed = false;
  for (const user of db.users) {
    if (
      user.moderationStatus === 'pending_suspension' &&
      user.suspensionDeadlineAt &&
      new Date(user.suspensionDeadlineAt).getTime() <= nowMs
    ) {
      user.moderationStatus = 'suspended';
      changed = true;
    }
  }
  if (changed) saveDb();
}

function sanitizeHandle(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '')
    .slice(0, 24);
}

function createId(prefix: string): string {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

function isBlockedBetween(userA: string, userB: string): boolean {
  return db.blocks.some(
    (b) =>
      (b.blockerId === userA && b.blockedId === userB) ||
      (b.blockerId === userB && b.blockedId === userA)
  );
}

function toPublicUser(user: StoredUser, viewerId?: string) {
  const followersCount = db.follows.filter((f) => f.followingId === user.id).length;
  const followingCount = db.follows.filter((f) => f.followerId === user.id).length;
  const isFollowing = viewerId
    ? db.follows.some((f) => f.followerId === viewerId && f.followingId === user.id)
    : false;
  const isBlocked = viewerId
    ? db.blocks.some((b) => b.blockerId === viewerId && b.blockedId === user.id)
    : false;
  const isOnline = activeSockets.has(user.id) || ['usr_sophia', 'usr_marcus', 'usr_aria'].includes(user.id);

  return {
    id: user.id,
    handle: user.handle,
    displayName: user.displayName,
    bio: user.bio,
    dpUrl: user.dpUrl,
    age: user.age,
    gender: user.gender,
    blackCoins: user.blackCoins,
    goldCoins: user.goldCoins,
    streakDays: user.streakDays,
    lastDailyClaimAt: user.lastDailyClaimAt,
    totalDailyGoldClaimed: user.totalDailyGoldClaimed,
    dinoHighScore: user.dinoHighScore,
    runnerHighScore: user.runnerHighScore,
    followersCount,
    followingCount,
    isFollowing,
    isBlocked,
    isOnline,
    moderationStatus: user.moderationStatus,
    suspensionReason: user.suspensionReason,
    suspensionScheduledAt: user.suspensionScheduledAt,
    suspensionDeadlineAt: user.suspensionDeadlineAt,
    acceptedTosAt: user.acceptedTosAt,
    acceptedPrivacyAt: user.acceptedPrivacyAt,
    createdAt: user.createdAt,
  };
}

function pushNotification(
  userId: string,
  category: StoredNotification['category'],
  title: string,
  body: string
): StoredNotification {
  const notif: StoredNotification = {
    id: createId('ntf'),
    userId,
    category,
    title,
    body,
    read: false,
    createdAt: new Date().toISOString(),
  };
  db.notifications.unshift(notif);
  if (db.notifications.length > 500) {
    db.notifications = db.notifications.slice(0, 500);
  }
  saveDb();

  const sockets = activeSockets.get(userId);
  if (sockets) {
    const payload = JSON.stringify({ type: 'notification:new', notification: notif });
    for (const ws of sockets) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      }
    }
  }
  return notif;
}

const activeSockets = new Map<string, Set<WebSocket>>();

interface QueueEntry {
  userId: string;
  gender: 'woman' | 'man' | 'non-binary';
  filter: 'all' | 'woman' | 'man' | 'non-binary';
  ws: WebSocket;
  joinedAt: number;
}

interface ActiveRoom {
  roomId: string;
  userA: string;
  userB: string;
  wsA: WebSocket;
  wsB: WebSocket;
  createdAt: number;
}

let callQueue: QueueEntry[] = [];
const activeRooms = new Map<string, ActiveRoom>();
const userActiveRoom = new Map<string, string>();

function sendWs(ws: WebSocket, data: unknown): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

function removeFromQueue(userId: string): void {
  callQueue = callQueue.filter((entry) => entry.userId !== userId);
}

function endRoom(roomId: string, reason: string, triggeredByUserId?: string): void {
  const room = activeRooms.get(roomId);
  if (!room) return;
  activeRooms.delete(roomId);
  userActiveRoom.delete(room.userA);
  userActiveRoom.delete(room.userB);

  const payload = {
    type: reason === 'moderation' ? 'call:terminated_moderation' : 'call:ended',
    roomId,
    reason,
    triggeredByUserId,
  };
  sendWs(room.wsA, payload);
  sendWs(room.wsB, payload);
}

function filterMatches(
  candidateGender: 'woman' | 'man' | 'non-binary',
  wantedFilter: 'all' | 'woman' | 'man' | 'non-binary'
): boolean {
  if (wantedFilter === 'all') return true;
  return candidateGender === wantedFilter;
}

function tryMatchUsers(entry: QueueEntry): boolean {
  const matchIndex = callQueue.findIndex((candidate) => {
    if (candidate.userId === entry.userId) return false;
    if (candidate.ws.readyState !== WebSocket.OPEN) return false;
    if (isBlockedBetween(entry.userId, candidate.userId)) return false;
    return (
      filterMatches(candidate.gender, entry.filter) &&
      filterMatches(entry.gender, candidate.filter)
    );
  });

  if (matchIndex === -1) return false;

  const [partner] = callQueue.splice(matchIndex, 1);
  removeFromQueue(entry.userId);

  const userA = db.users.find((u) => u.id === entry.userId);
  const userB = db.users.find((u) => u.id === partner.userId);
  if (!userA || !userB) return false;

  const roomId = createId('room');
  const room: ActiveRoom = {
    roomId,
    userA: userA.id,
    userB: userB.id,
    wsA: entry.ws,
    wsB: partner.ws,
    createdAt: Date.now(),
  };
  activeRooms.set(roomId, room);
  userActiveRoom.set(userA.id, roomId);
  userActiveRoom.set(userB.id, roomId);

  sendWs(entry.ws, {
    type: 'call:matched',
    roomId,
    isInitiator: true,
    peer: toPublicUser(userB, userA.id),
  });
  sendWs(partner.ws, {
    type: 'call:matched',
    roomId,
    isInitiator: false,
    peer: toPublicUser(userA, userB.id),
  });
  return true;
}

const app = express();
app.use(express.json({ limit: '10mb' }));

function getSessionUser(req: express.Request): StoredUser | null {
  enforcePendingSuspensions();
  const token = req.header('x-session-token');
  if (!token) return null;
  const userId = db.sessions[token];
  if (!userId) return null;
  return db.users.find((u) => u.id === userId) || null;
}

app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
  });
});

app.post('/api/auth/register', (req, res) => {
  const { displayName, handle, age, gender, dpUrl, bio, acceptedTos, acceptedPrivacy } = req.body as {
    displayName?: string;
    handle?: string;
    age?: number;
    gender?: 'woman' | 'man' | 'non-binary';
    dpUrl?: string;
    bio?: string;
    acceptedTos?: boolean;
    acceptedPrivacy?: boolean;
  };

  if (!acceptedTos || !acceptedPrivacy) {
    res.status(400).json({ error: 'You must accept the Terms of Service and Privacy Policy.' });
    return;
  }

  const parsedAge = Number(age);
  if (!Number.isFinite(parsedAge) || parsedAge < 1 || parsedAge > 120) {
    res.status(400).json({ error: 'Please enter a valid age.' });
    return;
  }

  const cleanHandle = sanitizeHandle(handle || displayName || 'player');
  if (cleanHandle.length < 3) {
    res.status(400).json({ error: 'Username must be at least 3 alphanumeric characters.' });
    return;
  }

  const existingByHandle = db.users.find((u) => u.handle === cleanHandle);
  if (existingByHandle) {
    res.status(409).json({ error: 'That handle is already taken. Try another or sign in.' });
    return;
  }

  const nowIso = new Date().toISOString();
  const newUser: StoredUser = {
    id: createId('usr'),
    handle: cleanHandle,
    displayName: (displayName || cleanHandle).trim().slice(0, 40),
    bio: (bio || 'Exploring Black Gold social & arcade.').trim().slice(0, 180),
    dpUrl:
      dpUrl && dpUrl.length > 0
        ? dpUrl
        : '/src/assets/images/avatar_sophia_1794896683221.jpg',
    age: Math.floor(parsedAge),
    gender: gender === 'man' || gender === 'non-binary' ? gender : 'woman',
    blackCoins: 500,
    goldCoins: 50,
    streakDays: 0,
    lastDailyClaimAt: null,
    totalDailyGoldClaimed: 0,
    dinoHighScore: 0,
    runnerHighScore: 0,
    moderationStatus: 'active',
    suspensionReason: null,
    suspensionScheduledAt: null,
    suspensionDeadlineAt: null,
    acceptedTosAt: nowIso,
    acceptedPrivacyAt: nowIso,
    createdAt: nowIso,
  };

  db.users.push(newUser);
  const token = createId('sess');
  db.sessions[token] = newUser.id;
  saveDb();

  pushNotification(
    newUser.id,
    'streak',
    'Welcome to Black Gold',
    'Your Day 1 reward of 1,000 Gold Coins is ready to claim in your Wallet.'
  );

  res.status(201).json({
    token,
    user: toPublicUser(newUser, newUser.id),
  });
});

app.post('/api/auth/login', (req, res) => {
  const { handle } = req.body as { handle?: string };
  const clean = sanitizeHandle(handle || '');
  const user = db.users.find((u) => u.handle === clean);
  if (!user) {
    res.status(404).json({ error: 'Account not found. Create a new Black Gold profile.' });
    return;
  }
  const token = createId('sess');
  db.sessions[token] = user.id;
  saveDb();
  res.json({
    token,
    user: toPublicUser(user, user.id),
  });
});

app.get('/api/auth/me', (req, res) => {
  const user = getSessionUser(req);
  if (!user) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  res.json({ user: toPublicUser(user, user.id) });
});

app.patch('/api/profile', (req, res) => {
  const user = getSessionUser(req);
  if (!user) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const { displayName, bio, dpUrl, gender } = req.body as {
    displayName?: string;
    bio?: string;
    dpUrl?: string;
    gender?: 'woman' | 'man' | 'non-binary';
  };
  if (typeof displayName === 'string' && displayName.trim().length >= 2) {
    user.displayName = displayName.trim().slice(0, 40);
  }
  if (typeof bio === 'string') {
    user.bio = bio.trim().slice(0, 180);
  }
  if (typeof dpUrl === 'string' && dpUrl.length > 0 && dpUrl.length < 1_500_000) {
    user.dpUrl = dpUrl;
  }
  if (gender === 'woman' || gender === 'man' || gender === 'non-binary') {
    user.gender = gender;
  }
  saveDb();
  res.json({ user: toPublicUser(user, user.id) });
});

app.get('/api/users', (req, res) => {
  const currentUser = getSessionUser(req);
  const viewerId = currentUser?.id;
  const users = db.users
    .filter((u) => {
      if (!viewerId) return true;
      if (u.id === viewerId) return false;
      return !db.blocks.some((b) => b.blockerId === u.id && b.blockedId === viewerId);
    })
    .map((u) => toPublicUser(u, viewerId));

  res.json({ users });
});

app.post('/api/users/:id/follow', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const targetId = req.params.id;
  if (targetId === currentUser.id) {
    res.status(400).json({ error: 'You cannot follow yourself.' });
    return;
  }
  const targetUser = db.users.find((u) => u.id === targetId);
  if (!targetUser) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  if (isBlockedBetween(currentUser.id, targetId)) {
    res.status(403).json({ error: 'Follow unavailable due to block settings.' });
    return;
  }

  const idx = db.follows.findIndex(
    (f) => f.followerId === currentUser.id && f.followingId === targetId
  );
  let following = false;
  if (idx >= 0) {
    db.follows.splice(idx, 1);
    following = false;
  } else {
    db.follows.push({
      followerId: currentUser.id,
      followingId: targetId,
      createdAt: new Date().toISOString(),
    });
    following = true;
    pushNotification(
      targetUser.id,
      'follow',
      'New Follower',
      `@${currentUser.handle} started following your profile.`
    );
  }
  saveDb();
  res.json({
    following,
    targetUser: toPublicUser(targetUser, currentUser.id),
    currentUser: toPublicUser(currentUser, currentUser.id),
  });
});

app.get('/api/stories', (req, res) => {
  const currentUser = getSessionUser(req);
  const viewerId = currentUser?.id;
  const nowMs = Date.now();

  const stories = db.stories
    .filter((s) => new Date(s.expiresAt).getTime() > nowMs)
    .filter((s) => !viewerId || !isBlockedBetween(viewerId, s.userId))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .map((s) => {
      const author = db.users.find((u) => u.id === s.userId);
      return {
        id: s.id,
        userId: s.userId,
        authorName: author?.displayName || 'Creator',
        authorHandle: author?.handle || 'creator',
        authorDp: author?.dpUrl || '/src/assets/images/avatar_sophia_1794896683221.jpg',
        mediaUrl: s.mediaUrl,
        caption: s.caption,
        createdAt: s.createdAt,
        expiresAt: s.expiresAt,
        viewedByCurrentUser: viewerId ? s.viewerIds.includes(viewerId) : false,
        viewsCount: s.viewerIds.length,
      };
    });

  res.json({ stories });
});

app.post('/api/stories', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  if (currentUser.moderationStatus === 'suspended') {
    res.status(403).json({ error: 'Suspended accounts cannot post stories.' });
    return;
  }
  const { mediaUrl, caption } = req.body as { mediaUrl?: string; caption?: string };
  if (!mediaUrl || mediaUrl.length > 2_000_000) {
    res.status(400).json({ error: 'Valid story image is required.' });
    return;
  }

  const now = new Date();
  const story: StoredStory = {
    id: createId('str'),
    userId: currentUser.id,
    mediaUrl,
    caption: (caption || '').trim().slice(0, 160),
    viewerIds: [currentUser.id],
    createdAt: now.toISOString(),
    expiresAt: new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString(),
  };
  db.stories.unshift(story);
  saveDb();

  res.status(201).json({
    story: {
      id: story.id,
      userId: story.userId,
      authorName: currentUser.displayName,
      authorHandle: currentUser.handle,
      authorDp: currentUser.dpUrl,
      mediaUrl: story.mediaUrl,
      caption: story.caption,
      createdAt: story.createdAt,
      expiresAt: story.expiresAt,
      viewedByCurrentUser: true,
      viewsCount: story.viewerIds.length,
    },
  });
});

app.post('/api/stories/:id/view', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const story = db.stories.find((s) => s.id === req.params.id);
  if (!story) {
    res.status(404).json({ error: 'Story not found' });
    return;
  }
  if (!story.viewerIds.includes(currentUser.id)) {
    story.viewerIds.push(currentUser.id);
    saveDb();
  }
  res.json({ ok: true, viewsCount: story.viewerIds.length });
});

app.get('/api/wallet/transactions', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const txs = db.transactions
    .filter(
      (t) =>
        t.userId === currentUser.id ||
        t.fromUserId === currentUser.id ||
        t.toUserId === currentUser.id
    )
    .slice(0, 50);
  res.json({ transactions: txs });
});

app.post('/api/wallet/claim-daily', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  if (currentUser.moderationStatus === 'suspended') {
    res.status(403).json({ error: 'Suspended accounts cannot claim daily rewards.' });
    return;
  }
  if (currentUser.streakDays >= 365) {
    res.status(400).json({ error: '365-day annual Gold Coin streak completed!' });
    return;
  }

  const now = new Date();
  if (currentUser.lastDailyClaimAt) {
    const last = new Date(currentUser.lastDailyClaimAt);
    const sameDay =
      last.getUTCFullYear() === now.getUTCFullYear() &&
      last.getUTCMonth() === now.getUTCMonth() &&
      last.getUTCDate() === now.getUTCDate();
    if (sameDay) {
      res.status(400).json({ error: 'Today’s 1,000 Gold Coins have already been claimed.' });
      return;
    }
  }

  const rewardAmount = 1000;
  currentUser.goldCoins += rewardAmount;
  currentUser.streakDays += 1;
  currentUser.lastDailyClaimAt = now.toISOString();
  currentUser.totalDailyGoldClaimed += rewardAmount;

  const tx: StoredTransaction = {
    id: createId('tx'),
    userId: currentUser.id,
    type: 'daily_reward',
    currency: 'gold',
    amount: rewardAmount,
    note: `365-Day Streak · Day ${currentUser.streakDays} Reward`,
    createdAt: now.toISOString(),
  };
  db.transactions.unshift(tx);
  saveDb();

  pushNotification(
    currentUser.id,
    'streak',
    'Daily Streak Claimed',
    `Day ${currentUser.streakDays}/365 unlocked: +1,000 Gold Coins added to your wallet.`
  );

  res.json({
    user: toPublicUser(currentUser, currentUser.id),
    transaction: tx,
  });
});

app.post('/api/wallet/convert', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const { direction, amount } = req.body as {
    direction?: 'gold_to_black' | 'black_to_gold';
    amount?: number;
  };
  const qty = Math.floor(Number(amount));
  if (!Number.isFinite(qty) || qty <= 0) {
    res.status(400).json({ error: 'Enter a positive integer amount to convert.' });
    return;
  }

  let tx: StoredTransaction;
  if (direction === 'gold_to_black') {
    if (currentUser.goldCoins < qty) {
      res.status(400).json({ error: 'Insufficient Gold Coins.' });
      return;
    }
    const blackReceived = qty * 10;
    currentUser.goldCoins -= qty;
    currentUser.blackCoins += blackReceived;
    tx = {
      id: createId('tx'),
      userId: currentUser.id,
      type: 'conversion',
      currency: 'black',
      amount: blackReceived,
      secondaryCurrency: 'gold',
      secondaryAmount: qty,
      note: `Converted ${qty} Gold → ${blackReceived} Black Coins`,
      createdAt: new Date().toISOString(),
    };
  } else if (direction === 'black_to_gold') {
    if (qty % 10 !== 0) {
      res.status(400).json({ error: 'Black Coins must be converted in multiples of 10.' });
      return;
    }
    if (currentUser.blackCoins < qty) {
      res.status(400).json({ error: 'Insufficient Black Coins.' });
      return;
    }
    const goldReceived = qty / 10;
    currentUser.blackCoins -= qty;
    currentUser.goldCoins += goldReceived;
    tx = {
      id: createId('tx'),
      userId: currentUser.id,
      type: 'conversion',
      currency: 'gold',
      amount: goldReceived,
      secondaryCurrency: 'black',
      secondaryAmount: qty,
      note: `Converted ${qty} Black → ${goldReceived} Gold Coins`,
      createdAt: new Date().toISOString(),
    };
  } else {
    res.status(400).json({ error: 'Invalid conversion direction.' });
    return;
  }

  db.transactions.unshift(tx);
  saveDb();
  res.json({ user: toPublicUser(currentUser, currentUser.id), transaction: tx });
});

app.post('/api/wallet/transfer', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  if (currentUser.moderationStatus === 'suspended') {
    res.status(403).json({ error: 'Suspended accounts cannot send coin transfers.' });
    return;
  }

  const { recipientHandle, currency, amount, note } = req.body as {
    recipientHandle?: string;
    currency?: 'black' | 'gold';
    amount?: number;
    note?: string;
  };

  const cleanHandle = sanitizeHandle((recipientHandle || '').replace(/^@/, ''));
  const recipient = db.users.find((u) => u.handle === cleanHandle);
  if (!recipient) {
    res.status(404).json({ error: 'Recipient handle not found.' });
    return;
  }
  if (recipient.id === currentUser.id) {
    res.status(400).json({ error: 'Cannot transfer coins to your own account.' });
    return;
  }
  if (isBlockedBetween(currentUser.id, recipient.id)) {
    res.status(403).json({ error: 'Transfers are disabled between blocked accounts.' });
    return;
  }

  const qty = Math.floor(Number(amount));
  if (!Number.isFinite(qty) || qty <= 0) {
    res.status(400).json({ error: 'Enter a valid positive amount.' });
    return;
  }
  if (currency !== 'black' && currency !== 'gold') {
    res.status(400).json({ error: 'Select Black Coins or Gold Coins.' });
    return;
  }

  if (currency === 'black') {
    if (currentUser.blackCoins < qty) {
      res.status(400).json({ error: 'Insufficient Black Coins.' });
      return;
    }
    currentUser.blackCoins -= qty;
    recipient.blackCoins += qty;
  } else {
    if (currentUser.goldCoins < qty) {
      res.status(400).json({ error: 'Insufficient Gold Coins.' });
      return;
    }
    currentUser.goldCoins -= qty;
    recipient.goldCoins += qty;
  }

  const tx: StoredTransaction = {
    id: createId('tx'),
    userId: currentUser.id,
    type: 'p2p_transfer',
    currency,
    amount: qty,
    fromUserId: currentUser.id,
    fromHandle: currentUser.handle,
    toUserId: recipient.id,
    toHandle: recipient.handle,
    note: (note || '').trim().slice(0, 80) || `Transfer to @${recipient.handle}`,
    createdAt: new Date().toISOString(),
  };
  db.transactions.unshift(tx);
  saveDb();

  const label = currency === 'gold' ? 'Gold Coins' : 'Black Coins';
  pushNotification(
    recipient.id,
    'transfer',
    'Coins Received',
    `@${currentUser.handle} sent you ${qty.toLocaleString()} ${label}.`
  );

  res.json({
    user: toPublicUser(currentUser, currentUser.id),
    transaction: tx,
  });
});

app.post('/api/games/reward', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const { game, survivalSeconds, score, pickupCoins } = req.body as {
    game?: 'dino' | 'runner';
    survivalSeconds?: number;
    score?: number;
    pickupCoins?: number;
  };

  const secs = Math.max(0, Math.min(3600, Number(survivalSeconds) || 0));
  const cleanScore = Math.max(0, Math.floor(Number(score) || 0));

  let awarded = 0;
  let currency: 'black' | 'gold' = 'black';
  let txType: 'game_dino' | 'game_runner' = 'game_dino';
  let note = '';

  if (game === 'dino') {
    awarded = Math.max(1, Math.floor((secs / 60) * 1000));
    currency = 'black';
    txType = 'game_dino';
    currentUser.blackCoins += awarded;
    if (cleanScore > currentUser.dinoHighScore) {
      currentUser.dinoHighScore = cleanScore;
    }
    note = `Dino Jump · ${secs.toFixed(1)}s survival (1,000 Black/min)`;
  } else if (game === 'runner') {
    const survivalGold = Math.floor((secs / 60) * 100);
    const safePickups = Math.max(0, Math.min(200, Math.floor(Number(pickupCoins) || 0)));
    awarded = Math.max(1, survivalGold + safePickups);
    currency = 'gold';
    txType = 'game_runner';
    currentUser.goldCoins += awarded;
    if (cleanScore > currentUser.runnerHighScore) {
      currentUser.runnerHighScore = cleanScore;
    }
    note = `Gold Rush Runner · ${secs.toFixed(1)}s survival (100 Gold/min + ${safePickups} pickups)`;
  } else {
    res.status(400).json({ error: 'Unknown game identifier.' });
    return;
  }

  const tx: StoredTransaction = {
    id: createId('tx'),
    userId: currentUser.id,
    type: txType,
    currency,
    amount: awarded,
    note,
    createdAt: new Date().toISOString(),
  };
  db.transactions.unshift(tx);
  saveDb();

  res.json({
    awarded,
    currency,
    user: toPublicUser(currentUser, currentUser.id),
    transaction: tx,
  });
});

app.post('/api/safety/report', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const { targetUserId, category, details, context } = req.body as {
    targetUserId?: string;
    category?: StoredReport['category'];
    details?: string;
    context?: StoredReport['context'];
  };
  const target = db.users.find((u) => u.id === targetUserId);
  if (!target) {
    res.status(404).json({ error: 'Reported user not found.' });
    return;
  }

  const report: StoredReport = {
    id: createId('rep'),
    reporterId: currentUser.id,
    targetUserId: target.id,
    targetHandle: target.handle,
    category: category || 'inappropriate_content',
    details: (details || '').trim().slice(0, 400),
    context: context || 'profile',
    createdAt: new Date().toISOString(),
  };
  db.reports.unshift(report);
  saveDb();

  pushNotification(
    currentUser.id,
    'system',
    'Safety Report Logged',
    `Your report regarding @${target.handle} has been logged for immediate review.`
  );

  res.status(201).json({ report });
});

app.post('/api/safety/block', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const { targetUserId } = req.body as { targetUserId?: string };
  if (!targetUserId || targetUserId === currentUser.id) {
    res.status(400).json({ error: 'Invalid user to block.' });
    return;
  }
  const target = db.users.find((u) => u.id === targetUserId);
  if (!target) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  const exists = db.blocks.some(
    (b) => b.blockerId === currentUser.id && b.blockedId === targetUserId
  );
  if (!exists) {
    db.blocks.push({
      blockerId: currentUser.id,
      blockedId: targetUserId,
      createdAt: new Date().toISOString(),
    });
  }
  db.follows = db.follows.filter(
    (f) =>
      !(f.followerId === currentUser.id && f.followingId === targetUserId) &&
      !(f.followerId === targetUserId && f.followingId === currentUser.id)
  );
  saveDb();

  const activeRoomId = userActiveRoom.get(currentUser.id);
  if (activeRoomId) {
    const room = activeRooms.get(activeRoomId);
    if (room && (room.userA === targetUserId || room.userB === targetUserId)) {
      endRoom(activeRoomId, 'blocked', currentUser.id);
    }
  }

  res.json({ ok: true, blockedId: targetUserId });
});

app.delete('/api/safety/block/:targetId', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  db.blocks = db.blocks.filter(
    (b) => !(b.blockerId === currentUser.id && b.blockedId === req.params.targetId)
  );
  saveDb();
  res.json({ ok: true });
});

app.get('/api/safety/blocked', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const blockedIds = db.blocks
    .filter((b) => b.blockerId === currentUser.id)
    .map((b) => b.blockedId);
  const blockedUsers = db.users
    .filter((u) => blockedIds.includes(u.id))
    .map((u) => toPublicUser(u, currentUser.id));
  res.json({ blockedUsers });
});

app.get('/api/notifications', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const items = db.notifications.filter((n) => n.userId === currentUser.id).slice(0, 40);
  res.json({ notifications: items });
});

app.post('/api/notifications/read-all', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  for (const n of db.notifications) {
    if (n.userId === currentUser.id) n.read = true;
  }
  saveDb();
  res.json({ ok: true });
});

app.post('/api/moderation/analyze', async (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const { frameBase64, textSnippet, roomId } = req.body as {
    frameBase64?: string;
    textSnippet?: string;
    roomId?: string;
  };

  if (!frameBase64 && (!textSnippet || !textSnippet.trim())) {
    res.status(400).json({ error: 'Provide a video frame or message snippet to analyze.' });
    return;
  }

  if (!ai) {
    res.status(503).json({
      error: 'Gemini moderation service requires GEMINI_API_KEY configured in Secrets.',
    });
    return;
  }

  try {
    const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];
    if (frameBase64) {
      const cleaned = frameBase64.replace(/^data:image\/\w+;base64,/, '');
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: cleaned,
        },
      });
    }
    parts.push({
      text: `Analyze this live video call input for safety compliance on a 12+ social platform.
Flag violations ONLY for clear inappropriate content: nudity or sexual content, graphic violence or weapons threats, hate speech, severe harassment/abuse, self-harm, or illegal acts.
Normal friendly conversation, everyday clothing, portraits, or neutral scenes are SAFE (isViolation: false).
${textSnippet ? `Transcript / chat snippet: "${textSnippet.slice(0, 500)}"` : 'Evaluate the video frame visually.'}`,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: { parts },
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        systemInstruction:
          'You are an automated trust & safety moderation classifier for a 12+ live video platform. Respond strictly using the JSON schema.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isViolation: { type: Type.BOOLEAN },
            severity: { type: Type.STRING },
            category: { type: Type.STRING },
            reason: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
          },
          required: ['isViolation', 'severity', 'category', 'reason', 'confidence'],
        },
      },
    });

    const parsed = JSON.parse((response.text || '{}').trim()) as {
      isViolation?: boolean;
      severity?: 'none' | 'low' | 'high' | 'critical';
      category?: string;
      reason?: string;
      confidence?: number;
    };

    const isViolation = Boolean(parsed.isViolation);
    let suspensionDeadlineAt: string | null = null;

    if (isViolation) {
      const now = new Date();
      // Automatically enforce suspension within 24 hours (immediate video restriction + 24h enforcement window)
      const deadline = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();
      currentUser.moderationStatus = 'pending_suspension';
      currentUser.suspensionReason =
        parsed.reason || `AI Safety Moderation violation (${parsed.category || 'policy'}).`;
      currentUser.suspensionScheduledAt = now.toISOString();
      currentUser.suspensionDeadlineAt = deadline;
      suspensionDeadlineAt = deadline;
      saveDb();

      if (roomId) {
        endRoom(roomId, 'moderation', currentUser.id);
      } else {
        const activeId = userActiveRoom.get(currentUser.id);
        if (activeId) endRoom(activeId, 'moderation', currentUser.id);
      }

      pushNotification(
        currentUser.id,
        'moderation',
        'Account Suspension Scheduled (Within 24h)',
        `AI moderation detected inappropriate content (${parsed.category || 'safety violation'}). Video calling is disabled and full suspension takes effect within 24 hours.`
      );
    }

    res.json({
      result: {
        isViolation,
        severity: parsed.severity || (isViolation ? 'high' : 'none'),
        category: parsed.category || 'safe',
        reason: parsed.reason || 'Content complies with Black Gold safety guidelines.',
        confidence: typeof parsed.confidence === 'number' ? parsed.confidence : 0.95,
        actionTaken: isViolation ? 'suspended_within_24h' : 'cleared',
        suspensionDeadlineAt,
      },
      user: toPublicUser(currentUser, currentUser.id),
    });
  } catch (err) {
    console.error('Gemini moderation error:', err);
    res.status(500).json({
      error: 'AI moderation request failed. Please verify GEMINI_API_KEY and try again.',
    });
  }
});

app.post('/api/moderation/appeal-reset', (req, res) => {
  const currentUser = getSessionUser(req);
  if (!currentUser) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  currentUser.moderationStatus = 'active';
  currentUser.suspensionReason = null;
  currentUser.suspensionScheduledAt = null;
  currentUser.suspensionDeadlineAt = null;
  saveDb();
  res.json({ user: toPublicUser(currentUser, currentUser.id) });
});

async function startServer() {
  const httpServer = http.createServer(app);

  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws, req) => {
    const url = new URL(req.url || '/ws', `http://${req.headers.host || 'localhost'}`);
    const token = url.searchParams.get('token') || '';
    const userId = db.sessions[token];
    const user = userId ? db.users.find((u) => u.id === userId) : null;

    if (!user) {
      sendWs(ws, { type: 'ws:error', error: 'Unauthorized WebSocket session' });
      ws.close();
      return;
    }

    if (!activeSockets.has(user.id)) {
      activeSockets.set(user.id, new Set());
    }
    activeSockets.get(user.id)!.add(ws);

    sendWs(ws, {
      type: 'ws:connected',
      onlineCount: Math.max(3, activeSockets.size + 3),
      queueSize: callQueue.length,
    });

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString()) as {
          type: string;
          filter?: 'all' | 'woman' | 'man' | 'non-binary';
          roomId?: string;
          payload?: unknown;
          text?: string;
        };

        const freshUser = db.users.find((u) => u.id === user.id);
        if (!freshUser) return;

        if (msg.type === 'call:join_queue') {
          enforcePendingSuspensions();
          if (freshUser.age < 12) {
            sendWs(ws, {
              type: 'call:rejected',
              code: 'AGE_RESTRICTED_12_PLUS',
              error: 'Random video calling is strictly restricted to users aged 12 and above.',
            });
            return;
          }
          if (freshUser.moderationStatus !== 'active') {
            sendWs(ws, {
              type: 'call:rejected',
              code: 'ACCOUNT_SUSPENDED',
              error: 'Video calling is locked due to an active AI moderation suspension.',
            });
            return;
          }

          removeFromQueue(freshUser.id);
          const filter =
            msg.filter === 'woman' || msg.filter === 'man' || msg.filter === 'non-binary'
              ? msg.filter
              : 'all';

          const entry: QueueEntry = {
            userId: freshUser.id,
            gender: freshUser.gender,
            filter,
            ws,
            joinedAt: Date.now(),
          };
          const matched = tryMatchUsers(entry);
          if (!matched) {
            callQueue.push(entry);
            sendWs(ws, {
              type: 'call:queued',
              queueSize: callQueue.length,
              filter,
            });
          }
          return;
        }

        if (msg.type === 'call:leave_queue') {
          removeFromQueue(freshUser.id);
          sendWs(ws, { type: 'call:left_queue' });
          return;
        }

        if (
          msg.type === 'webrtc:offer' ||
          msg.type === 'webrtc:answer' ||
          msg.type === 'webrtc:ice' ||
          msg.type === 'call:chat'
        ) {
          const roomId = msg.roomId || userActiveRoom.get(freshUser.id);
          if (!roomId) return;
          const room = activeRooms.get(roomId);
          if (!room) return;
          const peerWs = room.userA === freshUser.id ? room.wsB : room.wsA;
          sendWs(peerWs, {
            type: msg.type,
            roomId,
            fromUserId: freshUser.id,
            payload: msg.payload,
            text: msg.text,
          });
          return;
        }

        if (msg.type === 'call:end') {
          const roomId = msg.roomId || userActiveRoom.get(freshUser.id);
          if (roomId) {
            endRoom(roomId, 'user_ended', freshUser.id);
          }
          return;
        }
      } catch (err) {
        console.error('WS message error:', err);
      }
    });

    ws.on('close', () => {
      const set = activeSockets.get(user.id);
      if (set) {
        set.delete(ws);
        if (set.size === 0) {
          activeSockets.delete(user.id);
        }
      }
      removeFromQueue(user.id);
      const activeRoomId = userActiveRoom.get(user.id);
      if (activeRoomId) {
        endRoom(activeRoomId, 'peer_disconnected', user.id);
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Black Gold server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
