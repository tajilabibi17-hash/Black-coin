import type {
  AppNotification,
  CoinTransaction,
  CurrencyType,
  GenderIdentity,
  ModerationAnalysisResult,
  SafetyReport,
  StoryItem,
  UserProfile,
} from '../types';

const TOKEN_KEY = 'black_gold_session_token';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    // Ignore storage quota errors
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('x-session-token', token);
  }

  const res = await fetch(path, { ...options, headers });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

export const api = {
  register: (payload: {
    displayName: string;
    handle: string;
    age: number;
    gender: GenderIdentity;
    dpUrl: string;
    bio?: string;
    acceptedTos: boolean;
    acceptedPrivacy: boolean;
  }) => request<{ token: string; user: UserProfile }>('/api/auth/register', { method: 'POST', body: JSON.stringify(payload) }),

  login: (handle: string) =>
    request<{ token: string; user: UserProfile }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ handle }),
    }),

  me: () => request<{ user: UserProfile }>('/api/auth/me'),

  updateProfile: (payload: {
    displayName?: string;
    bio?: string;
    dpUrl?: string;
    gender?: GenderIdentity;
  }) => request<{ user: UserProfile }>('/api/profile', { method: 'PATCH', body: JSON.stringify(payload) }),

  listUsers: () => request<{ users: UserProfile[] }>('/api/users'),

  toggleFollow: (userId: string) =>
    request<{ following: boolean; targetUser: UserProfile; currentUser: UserProfile }>(
      `/api/users/${encodeURIComponent(userId)}/follow`,
      { method: 'POST' }
    ),

  listStories: () => request<{ stories: StoryItem[] }>('/api/stories'),

  createStory: (mediaUrl: string, caption: string) =>
    request<{ story: StoryItem }>('/api/stories', {
      method: 'POST',
      body: JSON.stringify({ mediaUrl, caption }),
    }),

  viewStory: (storyId: string) =>
    request<{ ok: boolean; viewsCount: number }>(`/api/stories/${encodeURIComponent(storyId)}/view`, {
      method: 'POST',
    }),

  listTransactions: () => request<{ transactions: CoinTransaction[] }>('/api/wallet/transactions'),

  claimDailyGold: () =>
    request<{ user: UserProfile; transaction: CoinTransaction }>('/api/wallet/claim-daily', {
      method: 'POST',
    }),

  convertCoins: (direction: 'gold_to_black' | 'black_to_gold', amount: number) =>
    request<{ user: UserProfile; transaction: CoinTransaction }>('/api/wallet/convert', {
      method: 'POST',
      body: JSON.stringify({ direction, amount }),
    }),

  transferCoins: (payload: {
    recipientHandle: string;
    currency: CurrencyType;
    amount: number;
    note?: string;
  }) =>
    request<{ user: UserProfile; transaction: CoinTransaction }>('/api/wallet/transfer', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  submitGameReward: (payload: {
    game: 'dino' | 'runner';
    survivalSeconds: number;
    score: number;
    pickupCoins?: number;
  }) =>
    request<{ awarded: number; currency: CurrencyType; user: UserProfile; transaction: CoinTransaction }>(
      '/api/games/reward',
      { method: 'POST', body: JSON.stringify(payload) }
    ),

  reportUser: (payload: {
    targetUserId: string;
    category: SafetyReport['category'];
    details: string;
    context: SafetyReport['context'];
  }) => request<{ report: SafetyReport }>('/api/safety/report', { method: 'POST', body: JSON.stringify(payload) }),

  blockUser: (targetUserId: string) =>
    request<{ ok: boolean; blockedId: string }>('/api/safety/block', {
      method: 'POST',
      body: JSON.stringify({ targetUserId }),
    }),

  unblockUser: (targetUserId: string) =>
    request<{ ok: boolean }>(`/api/safety/block/${encodeURIComponent(targetUserId)}`, {
      method: 'DELETE',
    }),

  listBlockedUsers: () => request<{ blockedUsers: UserProfile[] }>('/api/safety/blocked'),

  listNotifications: () => request<{ notifications: AppNotification[] }>('/api/notifications'),

  markAllNotificationsRead: () =>
    request<{ ok: boolean }>('/api/notifications/read-all', { method: 'POST' }),

  analyzeModeration: (payload: { frameBase64?: string; textSnippet?: string; roomId?: string }) =>
    request<{ result: ModerationAnalysisResult; user: UserProfile }>('/api/moderation/analyze', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  appealReset: () => request<{ user: UserProfile }>('/api/moderation/appeal-reset', { method: 'POST' }),
};

export async function resizeImageToDataUrl(file: File, maxSize = 640): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable'));
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      };
      img.onerror = () => reject(new Error('Could not decode selected image'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

export async function requestBrowserPushPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  if (Notification.permission === 'granted') return 'granted';
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

export function dispatchBrowserPush(title: string, body: string): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'granted') {
    try {
      new Notification(`Black Gold · ${title}`, {
        body,
        tag: 'black-gold-alert',
      });
    } catch {
      // Some mobile WebViews restrict Notification constructor directly
    }
  }
}
