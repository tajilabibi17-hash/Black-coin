import { useCallback, useEffect, useRef, useState } from 'react';
import { Coins, Flame } from 'lucide-react';
import {
  api,
  dispatchBrowserPush,
  getStoredToken,
  requestBrowserPushPermission,
  setStoredToken,
} from './lib/api';
import type {
  AppNotification,
  AppTab,
  SafetyReport,
  StoryItem,
  UserProfile,
} from './types';
import { AuthOnboarding } from './components/AuthOnboarding';
import { LegalModal } from './components/LegalModal';
import { TopNav, MobileBottomNav } from './components/TopNav';
import { SocialFeed } from './components/SocialFeed';
import { VideoCallStudio } from './components/VideoCallStudio';
import { DinoJumpGame } from './components/DinoJumpGame';
import { GoldRunnerGame } from './components/GoldRunnerGame';
import { WalletView } from './components/WalletView';
import { ProfileSafetyView } from './components/ProfileSafetyView';
import { ReportBlockModal } from './components/ReportBlockModal';
import { NotificationsDrawer } from './components/NotificationsDrawer';

export default function App() {
  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [booting, setBooting] = useState(Boolean(getStoredToken()));

  const [activeTab, setActiveTab] = useState<AppTab>('feed');
  const [selectedGame, setSelectedGame] = useState<'dino' | 'runner'>('dino');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [stories, setStories] = useState<StoryItem[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const [legalTab, setLegalTab] = useState<'tos' | 'privacy' | null>(null);
  const [reportTarget, setReportTarget] = useState<{
    user: UserProfile;
    context: SafetyReport['context'];
  } | null>(null);
  const [walletRecipient, setWalletRecipient] = useState<string | undefined>(undefined);

  const [pushPermission, setPushPermission] = useState<NotificationPermission | 'unsupported'>(
    () => {
      if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported';
      return Notification.permission;
    }
  );

  const wsRef = useRef<WebSocket | null>(null);
  const [wsConnected, setWsConnected] = useState(false);

  const refreshData = useCallback(async () => {
    if (!getStoredToken()) return;
    try {
      const [meRes, usersRes, storiesRes, notifRes] = await Promise.all([
        api.me(),
        api.listUsers(),
        api.listStories(),
        api.listNotifications(),
      ]);
      setCurrentUser(meRes.user);
      setUsers(usersRes.users);
      setStories(storiesRes.stories);
      setNotifications(notifRes.notifications);
    } catch {
      // Session invalid or network glitch
    }
  }, []);

  useEffect(() => {
    if (!token) {
      setBooting(false);
      return;
    }
    let mounted = true;
    (async () => {
      try {
        const res = await api.me();
        if (!mounted) return;
        setCurrentUser(res.user);
        await refreshData();
      } catch {
        setStoredToken(null);
        setToken(null);
        setCurrentUser(null);
      } finally {
        if (mounted) setBooting(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [token, refreshData]);

  // Persistent WebSocket connection with automatic reconnect
  useEffect(() => {
    if (!token || !currentUser) return;

    let closedIntentionally = false;
    let reconnectTimer: number | undefined;

    const connect = () => {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const socket = new WebSocket(`${proto}//${window.location.host}/ws?token=${encodeURIComponent(token)}`);
      wsRef.current = socket;

      socket.onopen = () => {
        setWsConnected(true);
      };

      socket.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data as string) as {
            type: string;
            notification?: AppNotification;
          };
          if (msg.type === 'notification:new' && msg.notification) {
            const notif = msg.notification;
            setNotifications((prev) => [notif, ...prev]);
            dispatchBrowserPush(notif.title, notif.body);
            void refreshData();
          }
        } catch {
          // Non-JSON payload ignored
        }
      };

      socket.onclose = () => {
        setWsConnected(false);
        if (!closedIntentionally) {
          reconnectTimer = window.setTimeout(connect, 2500);
        }
      };
    };

    connect();

    return () => {
      closedIntentionally = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [token, currentUser?.id, refreshData]);

  function handleAuthenticated(newToken: string, user: UserProfile) {
    setStoredToken(newToken);
    setToken(newToken);
    setCurrentUser(user);
    setActiveTab('feed');
    void refreshData();
  }

  function handleLogout() {
    setStoredToken(null);
    setToken(null);
    setCurrentUser(null);
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }

  async function handleEnablePush() {
    const res = await requestBrowserPushPermission();
    setPushPermission(res);
  }

  async function handleMarkAllRead() {
    try {
      await api.markAllNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    } catch {
      // Ignore
    }
  }

  if (booting) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center space-y-2">
          <p className="font-display text-3xl font-semibold text-[#181510]">Black Gold</p>
          <p className="text-xs text-[#6C6352]">Loading your treasury...</p>
        </div>
      </div>
    );
  }

  if (!currentUser || !token) {
    return (
      <>
        <AuthOnboarding
          onAuthenticated={handleAuthenticated}
          onOpenLegal={(tab) => setLegalTab(tab)}
        />
        <LegalModal
          openTab={legalTab}
          onClose={() => setLegalTab(null)}
          onSwitchTab={(tab) => setLegalTab(tab)}
        />
      </>
    );
  }

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-white text-[#181510] flex flex-col">
      <TopNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        unreadNotifications={unreadCount}
        onOpenNotifications={() => setNotificationsOpen(true)}
      />

      {/* Compact Treasury Strip below Header */}
      <div className="bg-[#FBF9F4] border-b border-[#E8DEC5]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={currentUser.dpUrl}
              alt={currentUser.displayName}
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-full object-cover border border-[#D4AF37] shrink-0"
            />
            <span className="font-semibold text-[#181510] truncate">
              {currentUser.displayName}
            </span>
            <span className="text-[#6C6352] hidden sm:inline">@{currentUser.handle}</span>
          </div>

          <div className="flex items-center gap-4 font-mono-num">
            <button
              type="button"
              onClick={() => setActiveTab('wallet')}
              className="flex items-center gap-1.5 hover:text-[#997312] transition-colors cursor-pointer"
            >
              <Coins className="w-3.5 h-3.5 text-[#C59B27]" />
              <strong className="text-[#997312]">
                {currentUser.goldCoins.toLocaleString()}
              </strong>
              <span className="text-[#6C6352]">Gold</span>
            </button>

            <span className="text-[#D8CEB6]" aria-hidden="true">
              /
            </span>

            <button
              type="button"
              onClick={() => setActiveTab('wallet')}
              className="flex items-center gap-1.5 hover:text-[#181510] transition-colors cursor-pointer"
            >
              <Coins className="w-3.5 h-3.5 text-[#181510]" />
              <strong className="text-[#181510]">
                {currentUser.blackCoins.toLocaleString()}
              </strong>
              <span className="text-[#6C6352]">Black</span>
            </button>

            <span className="text-[#D8CEB6] hidden sm:inline" aria-hidden="true">
              ·
            </span>

            <button
              type="button"
              onClick={() => setActiveTab('wallet')}
              className="hidden sm:flex items-center gap-1 text-[#997312] font-semibold cursor-pointer"
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Day {currentUser.streakDays}/365</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-12">
        {activeTab === 'feed' && (
          <SocialFeed
            currentUser={currentUser}
            users={users}
            stories={stories}
            onRefreshData={refreshData}
            onUserUpdated={setCurrentUser}
            onOpenReportModal={(user, context) => setReportTarget({ user, context })}
            onQuickTransferTo={(handle) => {
              setWalletRecipient(handle);
              setActiveTab('wallet');
            }}
          />
        )}

        {activeTab === 'video' && (
          <VideoCallStudio
            currentUser={currentUser}
            ws={wsRef.current}
            wsConnected={wsConnected}
            onUserUpdated={setCurrentUser}
            onOpenReportModal={(user, context) => setReportTarget({ user, context })}
          />
        )}

        {activeTab === 'games' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-3xl font-semibold text-[#181510]">
                  Black Gold Arcade
                </h2>
                <p className="text-xs sm:text-sm text-[#6C6352]">
                  Earn Black Tokens in Dino Jump (1,000/min) or Gold Coins in Gold Rush Runner (100/min).
                </p>
              </div>

              <div className="flex items-center gap-1 p-1 bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg self-start">
                <button
                  type="button"
                  onClick={() => setSelectedGame('dino')}
                  className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    selectedGame === 'dino'
                      ? 'bg-[#181510] text-white'
                      : 'text-[#6C6352] hover:text-[#181510]'
                  }`}
                >
                  Dino Jump (Black)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedGame('runner')}
                  className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    selectedGame === 'runner'
                      ? 'bg-[#C59B27] text-white'
                      : 'text-[#6C6352] hover:text-[#181510]'
                  }`}
                >
                  Gold Rush Runner (Gold)
                </button>
              </div>
            </div>

            {selectedGame === 'dino' ? (
              <DinoJumpGame currentUser={currentUser} onUserUpdated={setCurrentUser} />
            ) : (
              <GoldRunnerGame currentUser={currentUser} onUserUpdated={setCurrentUser} />
            )}
          </div>
        )}

        {activeTab === 'wallet' && (
          <WalletView
            currentUser={currentUser}
            users={users}
            prefillRecipient={walletRecipient}
            onUserUpdated={setCurrentUser}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileSafetyView
            currentUser={currentUser}
            pushPermission={pushPermission}
            onEnablePush={handleEnablePush}
            onUserUpdated={setCurrentUser}
            onOpenLegal={(tab) => setLegalTab(tab)}
            onLogout={handleLogout}
            onRefreshUsers={refreshData}
          />
        )}
      </main>

      <footer className="hidden md:block border-t border-[#E8DEC5] bg-[#FBF9F4] py-5 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between text-xs text-[#6C6352]">
          <span>Black Gold · Social, Video &amp; Arcade</span>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => setLegalTab('tos')}
              className="hover:text-[#181510] underline underline-offset-2"
            >
              Terms of Service
            </button>
            <button
              type="button"
              onClick={() => setLegalTab('privacy')}
              className="hover:text-[#181510] underline underline-offset-2"
            >
              Privacy Policy
            </button>
          </div>
        </div>
      </footer>

      <MobileBottomNav activeTab={activeTab} onSelectTab={setActiveTab} />

      <LegalModal
        openTab={legalTab}
        onClose={() => setLegalTab(null)}
        onSwitchTab={(tab) => setLegalTab(tab)}
      />

      <ReportBlockModal
        targetUser={reportTarget?.user || null}
        context={reportTarget?.context || 'profile'}
        onClose={() => setReportTarget(null)}
        onBlocked={() => {
          void refreshData();
        }}
      />

      <NotificationsDrawer
        open={notificationsOpen}
        notifications={notifications}
        pushPermission={pushPermission}
        onEnablePush={handleEnablePush}
        onMarkAllRead={handleMarkAllRead}
        onClose={() => setNotificationsOpen(false)}
      />
    </div>
  );
}
