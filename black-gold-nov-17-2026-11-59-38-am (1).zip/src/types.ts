export type GenderIdentity = 'woman' | 'man' | 'non-binary';
export type GenderFilter = 'all' | 'woman' | 'man' | 'non-binary';
export type CurrencyType = 'black' | 'gold';
export type ModerationStatus = 'active' | 'pending_suspension' | 'suspended';
export type AppTab = 'feed' | 'video' | 'games' | 'wallet' | 'profile';

export interface UserProfile {
  id: string;
  handle: string;
  displayName: string;
  bio: string;
  dpUrl: string;
  age: number;
  gender: GenderIdentity;
  blackCoins: number;
  goldCoins: number;
  streakDays: number;
  lastDailyClaimAt: string | null;
  totalDailyGoldClaimed: number;
  dinoHighScore: number;
  runnerHighScore: number;
  followersCount: number;
  followingCount: number;
  isFollowing?: boolean;
  isBlocked?: boolean;
  isOnline?: boolean;
  moderationStatus: ModerationStatus;
  suspensionReason?: string | null;
  suspensionScheduledAt?: string | null;
  suspensionDeadlineAt?: string | null;
  acceptedTosAt: string;
  acceptedPrivacyAt: string;
  createdAt: string;
}

export interface StoryItem {
  id: string;
  userId: string;
  authorName: string;
  authorHandle: string;
  authorDp: string;
  mediaUrl: string;
  caption: string;
  createdAt: string;
  expiresAt: string;
  viewedByCurrentUser?: boolean;
  viewsCount: number;
}

export interface CoinTransaction {
  id: string;
  type:
    | 'daily_reward'
    | 'conversion'
    | 'p2p_transfer'
    | 'game_dino'
    | 'game_runner'
    | 'story_tip';
  currency: CurrencyType;
  amount: number;
  secondaryCurrency?: CurrencyType;
  secondaryAmount?: number;
  fromUserId?: string;
  fromHandle?: string;
  toUserId?: string;
  toHandle?: string;
  note: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  category: 'transfer' | 'follow' | 'streak' | 'moderation' | 'system';
  title: string;
  body: string;
  read: boolean;
  createdAt: string;
}

export interface SafetyReport {
  id: string;
  reporterId: string;
  targetUserId: string;
  targetHandle: string;
  category: 'inappropriate_content' | 'harassment' | 'underage_under_12' | 'spam_scam';
  details: string;
  context: 'profile' | 'story' | 'video_call';
  createdAt: string;
}

export interface ModerationAnalysisResult {
  isViolation: boolean;
  severity: 'none' | 'low' | 'high' | 'critical';
  category: string;
  reason: string;
  confidence: number;
  actionTaken: 'cleared' | 'suspended_within_24h';
  suspensionDeadlineAt?: string | null;
}
