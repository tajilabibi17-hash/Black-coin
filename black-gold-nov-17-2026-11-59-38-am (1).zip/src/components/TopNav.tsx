import { Bell, Compass, Video, Gamepad2, Wallet, User } from 'lucide-react';
import type { AppTab } from '../types';

interface TopNavProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  unreadNotifications: number;
  onOpenNotifications: () => void;
}

const NAV_ITEMS: Array<{ id: AppTab; label: string }> = [
  { id: 'feed', label: 'Feed' },
  { id: 'video', label: 'Video Call' },
  { id: 'games', label: 'Arcade' },
  { id: 'wallet', label: 'Wallet' },
  { id: 'profile', label: 'Profile' },
];

export function TopNav({
  activeTab,
  onSelectTab,
  unreadNotifications,
  onOpenNotifications,
}: TopNavProps) {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#E8DEC5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-8">
        <button
          type="button"
          onClick={() => onSelectTab('feed')}
          className="font-display text-2xl font-bold tracking-tight text-[#181510] whitespace-nowrap shrink-0 cursor-pointer"
        >
          Black Gold
        </button>

        <nav className="hidden md:flex items-center gap-7" aria-label="Primary Navigation">
          {NAV_ITEMS.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative py-1.5 text-sm font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active ? 'text-[#181510]' : 'text-[#6C6352] hover:text-[#181510]'
                }`}
              >
                {item.label}
                {active && (
                  <span className="absolute left-0 right-0 -bottom-[19px] h-[2px] bg-[#C59B27]" />
                )}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onOpenNotifications}
            className="min-h-[40px] px-4 py-2 rounded-lg bg-[#181510] hover:bg-[#2C261D] text-white text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Bell className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>
              Alerts{unreadNotifications > 0 ? ` (${unreadNotifications})` : ''}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}

export function MobileBottomNav({
  activeTab,
  onSelectTab,
}: {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
}) {
  const mobileItems: Array<{
    id: AppTab;
    label: string;
    Icon: typeof Compass;
  }> = [
    { id: 'feed', label: 'Feed', Icon: Compass },
    { id: 'video', label: 'Call', Icon: Video },
    { id: 'games', label: 'Arcade', Icon: Gamepad2 },
    { id: 'wallet', label: 'Wallet', Icon: Wallet },
    { id: 'profile', label: 'Profile', Icon: User },
  ];

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E8DEC5] pb-safe"
    >
      <div className="grid grid-cols-5 items-center h-14">
        {mobileItems.map(({ id, label, Icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectTab(id)}
              className={`min-h-[44px] flex flex-col items-center justify-center transition-colors ${
                active ? 'text-[#997312]' : 'text-[#6C6352]'
              }`}
            >
              <Icon className={`w-5 h-5 ${active ? 'stroke-[2.25]' : 'stroke-[1.75]'}`} />
              <span className="text-[10px] font-semibold tracking-tight mt-0.5 whitespace-nowrap">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
