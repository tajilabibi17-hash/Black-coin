import React, { useState } from 'react';
import {
  Plus,
  UserPlus,
  UserCheck,
  Flag,
  Send,
  X,
  ChevronLeft,
  ChevronRight,
  Upload,
  Eye,
  Coins,
} from 'lucide-react';
import { api, resizeImageToDataUrl } from '../lib/api';
import type { StoryItem, UserProfile } from '../types';

const STORY_PRESETS = [
  '/src/assets/images/story_gold_lounge_1794896685131.jpg',
  '/src/assets/images/story_arcade_trophy_1794896685241.jpg',
];

interface SocialFeedProps {
  currentUser: UserProfile;
  users: UserProfile[];
  stories: StoryItem[];
  onRefreshData: () => Promise<void>;
  onUserUpdated: (user: UserProfile) => void;
  onOpenReportModal: (user: UserProfile, context: 'profile' | 'story') => void;
  onQuickTransferTo: (handle: string) => void;
}

export function SocialFeed({
  currentUser,
  users,
  stories,
  onRefreshData,
  onUserUpdated,
  onOpenReportModal,
  onQuickTransferTo,
}: SocialFeedProps) {
  const [filter, setFilter] = useState<'all' | 'following' | 'online'>('all');
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);
  const [createStoryOpen, setCreateStoryOpen] = useState(false);
  const [storyMediaUrl, setStoryMediaUrl] = useState(STORY_PRESETS[0]);
  const [storyCaption, setStoryCaption] = useState('');
  const [postingStory, setPostingStory] = useState(false);
  const [followBusyId, setFollowBusyId] = useState<string | null>(null);
  const [tipStatus, setTipStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const visibleUsers = users.filter((u) => {
    if (u.isBlocked) return false;
    if (filter === 'following') return Boolean(u.isFollowing);
    if (filter === 'online') return Boolean(u.isOnline);
    return true;
  });

  async function handleToggleFollow(target: UserProfile) {
    setFollowBusyId(target.id);
    setError(null);
    try {
      const res = await api.toggleFollow(target.id);
      onUserUpdated(res.currentUser);
      await onRefreshData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Follow action failed');
    } finally {
      setFollowBusyId(null);
    }
  }

  async function handleOpenStory(index: number) {
    setActiveStoryIndex(index);
    const story = stories[index];
    if (story && !story.viewedByCurrentUser) {
      try {
        await api.viewStory(story.id);
        await onRefreshData();
      } catch {
        // Non-blocking
      }
    }
  }

  async function handleStoryFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await resizeImageToDataUrl(file, 900);
      setStoryMediaUrl(dataUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not process image');
    }
  }

  async function handlePublishStory(e: React.FormEvent) {
    e.preventDefault();
    setPostingStory(true);
    setError(null);
    try {
      await api.createStory(storyMediaUrl, storyCaption);
      setStoryCaption('');
      setCreateStoryOpen(false);
      await onRefreshData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to post story');
    } finally {
      setPostingStory(false);
    }
  }

  async function handleTipStoryAuthor(story: StoryItem, currency: 'black' | 'gold', amount: number) {
    if (story.userId === currentUser.id) return;
    setTipStatus(null);
    try {
      const res = await api.transferCoins({
        recipientHandle: story.authorHandle,
        currency,
        amount,
        note: `Story tip`,
      });
      onUserUpdated(res.user);
      setTipStatus(`Sent ${amount} ${currency === 'gold' ? 'Gold' : 'Black'} to @${story.authorHandle}`);
      setTimeout(() => setTipStatus(null), 2600);
    } catch (err) {
      setTipStatus(err instanceof Error ? err.message : 'Tip failed');
    }
  }

  const activeStory = activeStoryIndex !== null ? stories[activeStoryIndex] : null;

  return (
    <div className="space-y-8">
      {error && (
        <div className="px-4 py-3 rounded-xl bg-[#FDF4F2] border border-[#E5B8B0] text-xs font-medium text-[#8B2E1E]">
          {error}
        </div>
      )}

      {/* Stories Strip */}
      <section aria-label="24-Hour Stories" className="bg-[#FBF9F4] border border-[#E8DEC5] rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-display text-2xl font-semibold text-[#181510]">
              Live Stories
            </h2>
            <p className="text-xs text-[#6C6352]">
              24-hour visual moments from creators you follow
            </p>
          </div>
          <button
            type="button"
            onClick={() => setCreateStoryOpen(true)}
            className="min-h-[40px] px-4 py-2 bg-[#C59B27] hover:bg-[#B0871B] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Post Story</span>
          </button>
        </div>

        <div className="flex items-center gap-4 overflow-x-auto no-scrollbar pb-1">
          <button
            type="button"
            onClick={() => setCreateStoryOpen(true)}
            className="flex flex-col items-center gap-1.5 shrink-0 group min-w-[72px]"
          >
            <div className="relative w-16 h-16 rounded-full p-0.5 border-2 border-dashed border-[#C59B27] bg-white flex items-center justify-center">
              <img
                src={currentUser.dpUrl}
                alt={currentUser.displayName}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover opacity-85 group-hover:opacity-100 transition-opacity"
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full bg-[#181510] text-[#D4AF37] flex items-center justify-center border-2 border-white">
                <Plus className="w-3.5 h-3.5" />
              </span>
            </div>
            <span className="text-xs font-medium text-[#181510] truncate max-w-[76px]">
              Your Story
            </span>
          </button>

          {stories.map((story, idx) => (
            <button
              key={story.id}
              type="button"
              onClick={() => handleOpenStory(idx)}
              className="flex flex-col items-center gap-1.5 shrink-0 min-w-[72px] group"
            >
              <div
                className={`w-16 h-16 rounded-full p-[2.5px] ${
                  story.viewedByCurrentUser
                    ? 'border-2 border-[#D8CEB6]'
                    : 'gold-shimmer'
                }`}
              >
                <div className="w-full h-full rounded-full p-0.5 bg-white">
                  <img
                    src={story.authorDp}
                    alt={story.authorName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full rounded-full object-cover group-hover:scale-[1.03] transition-transform"
                  />
                </div>
              </div>
              <span className="text-xs font-medium text-[#181510] truncate max-w-[76px]">
                @{story.authorHandle}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Community Directory & Follower System */}
      <section aria-label="Community Directory" className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#181510]">
              Creators &amp; Players
            </h2>
            <p className="text-xs sm:text-sm text-[#6C6352]">
              Follow members, explore profiles, or send peer-to-peer Black &amp; Gold tips.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg self-start">
            {(
              [
                { id: 'all', label: 'All Members' },
                { id: 'following', label: 'Following' },
                { id: 'online', label: 'Online' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  filter === tab.id
                    ? 'bg-white text-[#181510] shadow-xs border border-[#E8DEC5]'
                    : 'text-[#6C6352] hover:text-[#181510]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {visibleUsers.length === 0 ? (
          <div className="bg-[#FBF9F4] border border-[#E8DEC5] rounded-2xl p-10 text-center text-sm text-[#6C6352]">
            No members match this filter yet. Switch to All Members to discover creators.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {visibleUsers.map((member) => (
              <article
                key={member.id}
                className="bg-white border border-[#E8DEC5] rounded-2xl p-5 flex flex-col justify-between gap-4 hover:border-[#C59B27] transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={member.dpUrl}
                        alt={member.displayName}
                        referrerPolicy="no-referrer"
                        className="w-14 h-14 rounded-full object-cover border border-[#D4AF37] shrink-0"
                      />
                      <div className="min-w-0">
                        <h3 className="text-base font-semibold text-[#181510] truncate">
                          {member.displayName}
                        </h3>
                        <p className="text-xs text-[#6C6352] truncate">
                          @{member.handle} · {member.age >= 12 ? '12+ Verified' : 'Youth'} ·{' '}
                          {member.isOnline ? 'Active' : 'Offline'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onOpenReportModal(member, 'profile')}
                      aria-label={`Report or block ${member.displayName}`}
                      className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-[#6C6352] hover:text-[#8B2E1E] hover:bg-[#FDF4F2] transition-colors shrink-0"
                    >
                      <Flag className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-xs text-[#3B3429] leading-relaxed line-clamp-2">
                    {member.bio}
                  </p>

                  <div className="flex items-center gap-4 pt-1 text-xs text-[#6C6352] font-mono-num">
                    <span>
                      <strong className="text-[#181510]">{member.followersCount}</strong> Followers
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      <strong className="text-[#181510]">{member.followingCount}</strong> Following
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      <strong className="text-[#997312]">{member.streakDays}d</strong> Streak
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-3 border-t border-[#F0E9D6]">
                  <button
                    type="button"
                    disabled={followBusyId === member.id}
                    onClick={() => handleToggleFollow(member)}
                    className={`flex-1 min-h-[42px] px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                      member.isFollowing
                        ? 'bg-[#FBF9F4] border border-[#E8DEC5] text-[#181510] hover:border-[#C59B27]'
                        : 'bg-[#181510] text-white hover:bg-[#2C261D]'
                    }`}
                  >
                    {member.isFollowing ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5 text-[#C59B27]" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5 text-[#D4AF37]" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => onQuickTransferTo(member.handle)}
                    className="min-h-[42px] px-3.5 py-2 rounded-xl border border-[#E8DEC5] hover:border-[#C59B27] bg-white text-xs font-semibold text-[#181510] flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <Send className="w-3.5 h-3.5 text-[#C59B27]" />
                    <span>Send Coins</span>
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* Story Viewer Modal */}
      {activeStory && activeStoryIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Story Viewer"
        >
          <div className="relative w-full max-w-md bg-white border border-[#E8DEC5] rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[#E8DEC5] bg-[#FBF9F4]">
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={activeStory.authorDp}
                  alt={activeStory.authorName}
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover border border-[#C59B27]"
                />
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-[#181510] truncate">
                    {activeStory.authorName}
                  </p>
                  <p className="text-[11px] text-[#6C6352] truncate">
                    @{activeStory.authorHandle} · <Eye className="w-3 h-3 inline" />{' '}
                    {activeStory.viewsCount}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveStoryIndex(null)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-[#6C6352] hover:text-[#181510]"
                aria-label="Close story viewer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative aspect-[3/4] bg-[#F5F0E4]">
              <img
                src={activeStory.mediaUrl}
                alt={activeStory.caption || 'Story'}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              {activeStory.caption && (
                <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/80 via-black/40 to-transparent text-white text-sm">
                  {activeStory.caption}
                </div>
              )}

              {activeStoryIndex > 0 && (
                <button
                  type="button"
                  onClick={() => handleOpenStory(activeStoryIndex - 1)}
                  aria-label="Previous story"
                  className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 text-[#181510] flex items-center justify-center shadow"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
              )}
              {activeStoryIndex < stories.length - 1 && (
                <button
                  type="button"
                  onClick={() => handleOpenStory(activeStoryIndex + 1)}
                  aria-label="Next story"
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/90 text-[#181510] flex items-center justify-center shadow"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              )}
            </div>

            {activeStory.userId !== currentUser.id && (
              <div className="p-3 bg-[#FBF9F4] border-t border-[#E8DEC5] flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleTipStoryAuthor(activeStory, 'black', 50)}
                  className="flex-1 min-h-[40px] px-3 py-2 rounded-lg bg-[#181510] text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <Coins className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Tip 50 Black</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleTipStoryAuthor(activeStory, 'gold', 10)}
                  className="flex-1 min-h-[40px] px-3 py-2 rounded-lg bg-[#C59B27] text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>Tip 10 Gold</span>
                </button>
              </div>
            )}
            {tipStatus && (
              <div className="px-4 py-2 bg-[#181510] text-[#D4AF37] text-xs font-medium text-center">
                {tipStatus}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create Story Modal */}
      {createStoryOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/45 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Publish Story"
        >
          <div className="w-full max-w-md bg-white border border-[#E8DEC5] rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4]">
              <h3 className="font-display text-xl font-semibold text-[#181510]">
                Publish 24h Story
              </h3>
              <button
                type="button"
                onClick={() => setCreateStoryOpen(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-[#6C6352]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePublishStory} className="p-5 space-y-4">
              <div className="aspect-[3/4] max-h-60 w-full rounded-xl overflow-hidden border border-[#E8DEC5] bg-[#FBF9F4]">
                <img
                  src={storyMediaUrl}
                  alt="Story preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex items-center gap-2">
                {STORY_PRESETS.map((preset, idx) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setStoryMediaUrl(preset)}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border transition-colors ${
                      storyMediaUrl === preset
                        ? 'border-[#C59B27] bg-[#FBF9F4] text-[#181510]'
                        : 'border-[#E8DEC5] text-[#6C6352]'
                    }`}
                  >
                    Editorial #{idx + 1}
                  </button>
                ))}
                <label className="ml-auto inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg cursor-pointer hover:border-[#C59B27]">
                  <Upload className="w-3.5 h-3.5 text-[#C59B27]" />
                  <span>Upload Photo</span>
                  <input type="file" accept="image/*" onChange={handleStoryFile} className="sr-only" />
                </label>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                  Story Caption
                </label>
                <input
                  type="text"
                  value={storyCaption}
                  onChange={(e) => setStoryCaption(e.target.value)}
                  placeholder="Share a quick moment..."
                  maxLength={160}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
                />
              </div>

              <button
                type="submit"
                disabled={postingStory}
                className="w-full min-h-[44px] bg-[#181510] hover:bg-[#2C261D] text-white text-sm font-semibold rounded-xl"
              >
                {postingStory ? 'Publishing...' : 'Publish Story (24h)'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
