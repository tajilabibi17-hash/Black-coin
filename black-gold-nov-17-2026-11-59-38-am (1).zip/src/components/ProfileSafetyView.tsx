import React, { useEffect, useState } from 'react';
import { Upload, ShieldCheck, Bell, FileText, LogOut, Ban } from 'lucide-react';
import { api, resizeImageToDataUrl } from '../lib/api';
import type { GenderIdentity, UserProfile } from '../types';

interface ProfileSafetyViewProps {
  currentUser: UserProfile;
  pushPermission: NotificationPermission | 'unsupported';
  onEnablePush: () => void;
  onUserUpdated: (user: UserProfile) => void;
  onOpenLegal: (tab: 'tos' | 'privacy') => void;
  onLogout: () => void;
  onRefreshUsers: () => Promise<void>;
}

export function ProfileSafetyView({
  currentUser,
  pushPermission,
  onEnablePush,
  onUserUpdated,
  onOpenLegal,
  onLogout,
  onRefreshUsers,
}: ProfileSafetyViewProps) {
  const [displayName, setDisplayName] = useState(currentUser.displayName);
  const [bio, setBio] = useState(currentUser.bio);
  const [dpUrl, setDpUrl] = useState(currentUser.dpUrl);
  const [gender, setGender] = useState<GenderIdentity>(currentUser.gender);
  const [blockedUsers, setBlockedUsers] = useState<UserProfile[]>([]);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  async function loadBlocked() {
    try {
      const res = await api.listBlockedUsers();
      setBlockedUsers(res.blockedUsers);
    } catch {
      // Non-blocking
    }
  }

  useEffect(() => {
    void loadBlocked();
  }, [currentUser.id]);

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await resizeImageToDataUrl(file, 480);
      setDpUrl(url);
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Failed to process DP');
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setStatus(null);
    try {
      const res = await api.updateProfile({ displayName, bio, dpUrl, gender });
      onUserUpdated(res.user);
      setStatus('Profile updated.');
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Update failed');
    } finally {
      setSaving(false);
    }
  }

  async function handleUnblock(userId: string) {
    try {
      await api.unblockUser(userId);
      await loadBlocked();
      await onRefreshUsers();
    } catch {
      // Ignore
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 bg-white border border-[#E8DEC5] rounded-2xl p-6 space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-3xl font-semibold text-[#181510]">
              Profile &amp; Identity
            </h2>
            <p className="text-xs text-[#6C6352]">
              @{currentUser.handle} · Age {currentUser.age} ({currentUser.age >= 12 ? '12+ Video Eligible' : 'Under 12'})
            </p>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="min-h-[40px] px-3.5 py-2 border border-[#E8DEC5] hover:border-[#181510] rounded-xl text-xs font-semibold text-[#181510] flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Switch Account</span>
          </button>
        </div>

        <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-[#FBF9F4] border border-[#E8DEC5] text-center font-mono-num">
          <div>
            <p className="text-lg font-semibold text-[#181510]">{currentUser.followersCount}</p>
            <p className="text-[11px] text-[#6C6352]">Followers</p>
          </div>
          <div>
            <p className="text-lg font-semibold text-[#181510]">{currentUser.followingCount}</p>
            <p className="text-[11px] text-[#6C6352]">Following</p>
          </div>
          <div>
            <p className="text-lg font-semibold text-[#997312]">{currentUser.streakDays}d</p>
            <p className="text-[11px] text-[#6C6352]">Streak</p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="flex items-center gap-4">
            <img
              src={dpUrl}
              alt={displayName}
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-full object-cover border-2 border-[#D4AF37]"
            />
            <label className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold bg-[#FBF9F4] border border-[#E8DEC5] rounded-xl cursor-pointer hover:border-[#C59B27] min-h-[42px]">
              <Upload className="w-4 h-4 text-[#C59B27]" />
              <span>Change Display Picture (DP)</span>
              <input type="file" accept="image/*" onChange={handleAvatarUpload} className="sr-only" />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                Display Name
              </label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                Gender Identity
              </label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as GenderIdentity)}
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
              >
                <option value="woman">Woman</option>
                <option value="man">Man</option>
                <option value="non-binary">Non-Binary</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181510] mb-1.5">Bio</label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={180}
              className="w-full px-3.5 py-2 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
            />
          </div>

          {status && (
            <p className="text-xs font-medium text-[#997312]">{status}</p>
          )}

          <button
            type="submit"
            disabled={saving}
            className="min-h-[44px] px-6 py-2.5 bg-[#181510] hover:bg-[#2C261D] text-white text-xs font-semibold rounded-xl"
          >
            {saving ? 'Saving...' : 'Save Profile'}
          </button>
        </form>
      </div>

      {/* Safety, Blocks, Push & Legal */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-[#FBF9F4] border border-[#E8DEC5] rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#C59B27]" />
            <h3 className="font-display text-2xl font-semibold text-[#181510]">
              Trust &amp; Engagement
            </h3>
          </div>

          <div className="p-4 rounded-xl bg-white border border-[#E8DEC5] flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-[#181510] flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5 text-[#C59B27]" />
                <span>Push Notifications</span>
              </p>
              <p className="text-[11px] text-[#6C6352] mt-0.5">
                Status: {pushPermission === 'granted' ? 'Active' : pushPermission}
              </p>
            </div>
            <button
              type="button"
              onClick={onEnablePush}
              className="px-3.5 py-2 text-xs font-semibold bg-[#C59B27] text-white rounded-lg whitespace-nowrap"
            >
              {pushPermission === 'granted' ? 'Enabled' : 'Enable'}
            </button>
          </div>

          <div className="p-4 rounded-xl bg-white border border-[#E8DEC5] space-y-2.5">
            <p className="text-xs font-semibold text-[#181510] flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-[#C59B27]" />
              <span>Legal Agreements</span>
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onOpenLegal('tos')}
                className="flex-1 py-2 text-xs font-semibold border border-[#E8DEC5] rounded-lg hover:border-[#C59B27] text-[#181510]"
              >
                Terms of Service
              </button>
              <button
                type="button"
                onClick={() => onOpenLegal('privacy')}
                className="flex-1 py-2 text-xs font-semibold border border-[#E8DEC5] rounded-lg hover:border-[#C59B27] text-[#181510]"
              >
                Privacy Policy
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white border border-[#E8DEC5] rounded-2xl p-6 space-y-3">
          <div className="flex items-center gap-2">
            <Ban className="w-4 h-4 text-[#8B2E1E]" />
            <h3 className="font-display text-xl font-semibold text-[#181510]">
              Blocked Accounts ({blockedUsers.length})
            </h3>
          </div>
          {blockedUsers.length === 0 ? (
            <p className="text-xs text-[#6C6352]">
              You have not blocked any accounts. Blocked users cannot view your stories, transfer
              coins, or match with you in video calls.
            </p>
          ) : (
            <div className="divide-y divide-[#F0E9D6]">
              {blockedUsers.map((bu) => (
                <div key={bu.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={bu.dpUrl}
                      alt={bu.displayName}
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <span className="text-xs font-semibold text-[#181510] truncate">
                      @{bu.handle}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleUnblock(bu.id)}
                    className="px-3 py-1.5 text-xs font-semibold border border-[#E8DEC5] rounded-lg hover:border-[#181510]"
                  >
                    Unblock
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
