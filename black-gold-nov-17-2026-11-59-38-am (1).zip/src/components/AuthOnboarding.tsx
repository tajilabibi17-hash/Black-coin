import React, { useState } from 'react';
import { ShieldCheck, Upload, ArrowRight, Sparkles } from 'lucide-react';
import { api, resizeImageToDataUrl } from '../lib/api';
import type { GenderIdentity, UserProfile } from '../types';

const PRESET_DPS = [
  {
    label: 'Sophia',
    url: '/src/assets/images/avatar_sophia_1794896683221.jpg',
  },
  {
    label: 'Marcus',
    url: '/src/assets/images/avatar_marcus_1794896684056.jpg',
  },
  {
    label: 'Aria',
    url: '/src/assets/images/avatar_aria_1794896684243.jpg',
  },
];

interface AuthOnboardingProps {
  onAuthenticated: (token: string, user: UserProfile) => void;
  onOpenLegal: (tab: 'tos' | 'privacy') => void;
}

export function AuthOnboarding({ onAuthenticated, onOpenLegal }: AuthOnboardingProps) {
  const [mode, setMode] = useState<'register' | 'login'>('register');
  const [displayName, setDisplayName] = useState('');
  const [handle, setHandle] = useState('');
  const [age, setAge] = useState('18');
  const [gender, setGender] = useState<GenderIdentity>('woman');
  const [dpUrl, setDpUrl] = useState(PRESET_DPS[0].url);
  const [acceptedTos, setAcceptedTos] = useState(true);
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(true);
  const [loginHandle, setLoginHandle] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await resizeImageToDataUrl(file, 480);
      setDpUrl(dataUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load image');
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (mode === 'register') {
        const res = await api.register({
          displayName: displayName.trim() || handle.trim(),
          handle: handle.trim(),
          age: Number(age),
          gender,
          dpUrl,
          acceptedTos,
          acceptedPrivacy,
        });
        onAuthenticated(res.token, res.user);
      } else {
        const res = await api.login(loginHandle.trim());
        onAuthenticated(res.token, res.user);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setLoading(false);
    }
  }

  async function handleQuickSwitch(presetHandle: string) {
    setError(null);
    setLoading(true);
    try {
      const res = await api.login(presetHandle);
      onAuthenticated(res.token, res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not sign in');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col justify-center py-10 px-4 sm:px-8">
      <div className="max-w-5xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        <div className="lg:col-span-5 flex flex-col justify-between bg-[#FBF9F4] border border-[#E8DEC5] rounded-2xl p-8">
          <div className="space-y-6">
            <div>
              <p className="text-xs font-semibold tracking-widest uppercase text-[#997312]">
                White &amp; Gold Edition
              </p>
              <h1 className="font-display text-4xl sm:text-5xl font-semibold text-[#181510] mt-2 leading-[1.08] text-balance">
                Black Gold
              </h1>
              <p className="text-sm text-[#6C6352] mt-3 leading-relaxed">
                Curated social stories, 12+ AI-moderated random video calling, dual-currency Black
                &amp; Gold economy, and high-frame-rate endless runners built for Web, iOS, and
                Android.
              </p>
            </div>

            <div className="border-t border-[#E8DEC5] pt-5 space-y-3 text-sm text-[#3B3429]">
              <div className="flex items-center justify-between">
                <span>Exchange Rate</span>
                <span className="font-mono-num font-semibold text-[#181510]">
                  1 Gold = 10 Black
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>365-Day Daily Streak</span>
                <span className="font-mono-num font-semibold text-[#997312]">
                  1,000 Gold / Day
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Dino Jump Payout</span>
                <span className="font-mono-num font-semibold text-[#181510]">
                  1,000 Black / Min
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Gold Rush Runner Payout</span>
                <span className="font-mono-num font-semibold text-[#997312]">
                  100 Gold / Min
                </span>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-[#E8DEC5]">
            <p className="text-xs font-medium text-[#6C6352] mb-3">
              Instant Member Sign-In (for multi-tab testing)
            </p>
            <div className="grid grid-cols-3 gap-2">
              {PRESET_DPS.map((member) => (
                <button
                  key={member.label}
                  type="button"
                  disabled={loading}
                  onClick={() => handleQuickSwitch(member.label.toLowerCase())}
                  className="flex flex-col items-center gap-1.5 p-2.5 bg-white border border-[#E8DEC5] rounded-xl hover:border-[#C59B27] transition-colors min-h-[44px]"
                >
                  <img
                    src={member.url}
                    alt={member.label}
                    referrerPolicy="no-referrer"
                    className="w-9 h-9 rounded-full object-cover border border-[#E8DEC5]"
                  />
                  <span className="text-xs font-medium text-[#181510]">@{member.label.toLowerCase()}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-[#E8DEC5] rounded-2xl p-6 sm:p-8 flex flex-col justify-center">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-1 p-1 bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg">
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                }}
                className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  mode === 'register'
                    ? 'bg-[#C59B27] text-white'
                    : 'text-[#6C6352] hover:text-[#181510]'
                }`}
              >
                Create Profile
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  mode === 'login'
                    ? 'bg-[#C59B27] text-white'
                    : 'text-[#6C6352] hover:text-[#181510]'
                }`}
              >
                Sign In
              </button>
            </div>
            <span className="text-xs text-[#6C6352] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#C59B27]" />
              12+ Video Safety
            </span>
          </div>

          {error && (
            <div
              role="alert"
              className="mb-4 px-4 py-3 rounded-xl bg-[#FDF4F2] border border-[#E5B8B0] text-xs font-medium text-[#8B2E1E]"
            >
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' ? (
              <>
                <div className="flex flex-col sm:flex-row sm:items-center gap-4 pb-2">
                  <img
                    src={dpUrl}
                    alt="Selected display picture"
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-full object-cover border-2 border-[#D4AF37] shrink-0"
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    {PRESET_DPS.map((preset) => (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => setDpUrl(preset.url)}
                        className={`p-0.5 rounded-full border-2 transition-colors ${
                          dpUrl === preset.url ? 'border-[#C59B27]' : 'border-transparent'
                        }`}
                        title={`Use ${preset.label} portrait`}
                      >
                        <img
                          src={preset.url}
                          alt={preset.label}
                          referrerPolicy="no-referrer"
                          className="w-9 h-9 rounded-full object-cover"
                        />
                      </button>
                    ))}
                    <label className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg cursor-pointer hover:border-[#C59B27] transition-colors min-h-[40px]">
                      <Upload className="w-3.5 h-3.5 text-[#C59B27]" />
                      <span>Upload DP</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="sr-only"
                      />
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                      Display Name
                    </label>
                    <input
                      type="text"
                      required
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Elena Sterling"
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                      Username Handle
                    </label>
                    <input
                      type="text"
                      required
                      value={handle}
                      onChange={(e) => setHandle(e.target.value)}
                      placeholder="elena_gold"
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                      Age (12+ required for Video Calls)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={120}
                      required
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm font-mono-num bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                      Gender Identity
                    </label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value as GenderIdentity)}
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
                    >
                      <option value="woman">Woman</option>
                      <option value="man">Man</option>
                      <option value="non-binary">Non-Binary</option>
                    </select>
                  </div>
                </div>

                <div className="pt-2 space-y-2.5 border-t border-[#E8DEC5]">
                  <label className="flex items-start gap-2.5 cursor-pointer text-xs text-[#4D4436]">
                    <input
                      type="checkbox"
                      checked={acceptedTos}
                      onChange={(e) => setAcceptedTos(e.target.checked)}
                      className="mt-0.5 accent-[#C59B27] w-4 h-4 rounded"
                    />
                    <span>
                      I agree to the{' '}
                      <button
                        type="button"
                        onClick={() => onOpenLegal('tos')}
                        className="font-semibold text-[#997312] underline underline-offset-2"
                      >
                        Terms of Service
                      </button>{' '}
                      including the 12+ video call rule and AI safety moderation policy.
                    </span>
                  </label>
                  <label className="flex items-start gap-2.5 cursor-pointer text-xs text-[#4D4436]">
                    <input
                      type="checkbox"
                      checked={acceptedPrivacy}
                      onChange={(e) => setAcceptedPrivacy(e.target.checked)}
                      className="mt-0.5 accent-[#C59B27] w-4 h-4 rounded"
                    />
                    <span>
                      I acknowledge the{' '}
                      <button
                        type="button"
                        onClick={() => onOpenLegal('privacy')}
                        className="font-semibold text-[#997312] underline underline-offset-2"
                      >
                        Privacy Policy
                      </button>{' '}
                      governing stories, WebRTC streams, and push notifications.
                    </span>
                  </label>
                </div>
              </>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                  Username Handle
                </label>
                <input
                  type="text"
                  required
                  value={loginHandle}
                  onChange={(e) => setLoginHandle(e.target.value)}
                  placeholder="sophia"
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] px-5 py-3 bg-[#181510] hover:bg-[#2C261D] text-white text-sm font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 disabled:opacity-60"
            >
              <span>
                {loading
                  ? 'Entering Black Gold...'
                  : mode === 'register'
                    ? 'Create Account & Claim 1,000 Gold'
                    : 'Sign In to Black Gold'}
              </span>
              <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
            </button>
          </form>

          <div className="mt-5 flex items-center justify-between text-xs text-[#6C6352]">
            <span className="inline-flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#C59B27]" />
              500 Black + 50 Gold starter bonus
            </span>
            <button
              type="button"
              onClick={() => onOpenLegal('tos')}
              className="hover:text-[#181510] underline underline-offset-2"
            >
              Legal &amp; Safety
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
