import { Bell, X, CheckCheck, ShieldAlert, Coins, UserPlus, Flame } from 'lucide-react';
import type { AppNotification } from '../types';

interface NotificationsDrawerProps {
  open: boolean;
  notifications: AppNotification[];
  pushPermission: NotificationPermission | 'unsupported';
  onEnablePush: () => void;
  onMarkAllRead: () => void;
  onClose: () => void;
}

export function NotificationsDrawer({
  open,
  notifications,
  pushPermission,
  onEnablePush,
  onMarkAllRead,
  onClose,
}: NotificationsDrawerProps) {
  if (!open) return null;

  function iconFor(category: AppNotification['category']) {
    if (category === 'transfer') return <Coins className="w-4 h-4 text-[#C59B27]" />;
    if (category === 'follow') return <UserPlus className="w-4 h-4 text-[#181510]" />;
    if (category === 'streak') return <Flame className="w-4 h-4 text-[#C59B27]" />;
    if (category === 'moderation') return <ShieldAlert className="w-4 h-4 text-[#8B2E1E]" />;
    return <Bell className="w-4 h-4 text-[#6C6352]" />;
  }

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="Notifications"
    >
      <div className="w-full max-w-md bg-white border-l border-[#E8DEC5] h-full flex flex-col shadow-2xl">
        <div className="px-5 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4] flex items-center justify-between">
          <div>
            <h3 className="font-display text-2xl font-semibold text-[#181510]">
              Push &amp; Activity Alerts
            </h3>
            <p className="text-xs text-[#6C6352]">Real-time engagement and safety notices</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-[#6C6352] hover:text-[#181510]"
            aria-label="Close alerts"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-3 border-b border-[#E8DEC5] bg-white flex items-center justify-between gap-3">
          <div className="text-xs text-[#3B3429]">
            Browser Push:{' '}
            <strong className="text-[#181510]">
              {pushPermission === 'granted'
                ? 'Enabled'
                : pushPermission === 'denied'
                  ? 'Blocked in Browser'
                  : pushPermission === 'unsupported'
                    ? 'In-App Only'
                    : 'Not Enabled'}
            </strong>
          </div>
          <div className="flex items-center gap-2">
            {pushPermission !== 'granted' && pushPermission !== 'unsupported' && (
              <button
                type="button"
                onClick={onEnablePush}
                className="px-3 py-1.5 text-xs font-semibold bg-[#C59B27] text-white rounded-lg whitespace-nowrap"
              >
                Enable Push
              </button>
            )}
            <button
              type="button"
              onClick={onMarkAllRead}
              className="px-2.5 py-1.5 text-xs font-medium text-[#6C6352] hover:text-[#181510] flex items-center gap-1 whitespace-nowrap"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Mark Read</span>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-[#F0E9D6]">
          {notifications.length === 0 ? (
            <div className="p-10 text-center text-sm text-[#6C6352]">
              No notifications yet. Follow creators, play mini-games, or claim your daily 1,000 Gold Coins.
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                className={`px-5 py-4 flex items-start gap-3 ${
                  n.read ? 'bg-white' : 'bg-[#FBF9F4]'
                }`}
              >
                <div className="w-9 h-9 rounded-full bg-white border border-[#E8DEC5] flex items-center justify-center shrink-0 mt-0.5">
                  {iconFor(n.category)}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-semibold text-[#181510]">{n.title}</p>
                    <span className="text-[11px] text-[#6C6352] font-mono-num shrink-0">
                      {new Date(n.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="text-xs text-[#4D4436] mt-0.5 leading-relaxed">{n.body}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
