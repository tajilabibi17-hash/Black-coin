import React, { useState } from 'react';
import { Flag, Ban, X, CheckCircle2 } from 'lucide-react';
import { api } from '../lib/api';
import type { SafetyReport, UserProfile } from '../types';

interface ReportBlockModalProps {
  targetUser: UserProfile | null;
  context: SafetyReport['context'];
  onClose: () => void;
  onBlocked: (blockedId: string) => void;
}

export function ReportBlockModal({
  targetUser,
  context,
  onClose,
  onBlocked,
}: ReportBlockModalProps) {
  const [category, setCategory] = useState<SafetyReport['category']>('inappropriate_content');
  const [details, setDetails] = useState('');
  const [alsoBlock, setAlsoBlock] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!targetUser) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!targetUser) return;
    setError(null);
    setSubmitting(true);
    try {
      await api.reportUser({
        targetUserId: targetUser.id,
        category,
        details: details.trim() || 'Reported by community member',
        context,
      });
      if (alsoBlock) {
        await api.blockUser(targetUser.id);
        onBlocked(targetUser.id);
      }
      setSubmitted(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit report');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleBlockOnly() {
    if (!targetUser) return;
    setError(null);
    setSubmitting(true);
    try {
      await api.blockUser(targetUser.id);
      onBlocked(targetUser.id);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to block user');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Report or Block User"
    >
      <div className="w-full max-w-md bg-white border border-[#E8DEC5] rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4]">
          <div className="flex items-center gap-2">
            <Flag className="w-4 h-4 text-[#997312]" />
            <h3 className="font-display text-xl font-semibold text-[#181510]">
              Safety Actions · @{targetUser.handle}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-[#6C6352] hover:text-[#181510]"
            aria-label="Close safety modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="p-6 text-center space-y-4">
            <CheckCircle2 className="w-10 h-10 text-[#C59B27] mx-auto" />
            <div>
              <h4 className="font-semibold text-[#181510]">Report Submitted</h4>
              <p className="text-xs text-[#6C6352] mt-1">
                Thank you for keeping Black Gold safe.{' '}
                {alsoBlock
                  ? `@${targetUser.handle} has also been blocked from your feed and calls.`
                  : 'Our trust & safety queue has received your report.'}
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-full py-2.5 bg-[#181510] text-white text-sm font-semibold rounded-xl"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-[#FDF4F2] border border-[#E5B8B0] text-xs text-[#8B2E1E]">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                Violation Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as SafetyReport['category'])}
                className="w-full px-3 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
              >
                <option value="inappropriate_content">Inappropriate or Explicit Content</option>
                <option value="harassment">Harassment or Hate Speech</option>
                <option value="underage_under_12">Suspected Underage User (&lt;12)</option>
                <option value="spam_scam">Spam or Coin Scam</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                Details (optional)
              </label>
              <textarea
                rows={3}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Describe what happened..."
                className="w-full px-3 py-2 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
              />
            </div>

            <label className="flex items-center gap-2.5 text-xs text-[#3B3429] cursor-pointer">
              <input
                type="checkbox"
                checked={alsoBlock}
                onChange={(e) => setAlsoBlock(e.target.checked)}
                className="accent-[#C59B27] w-4 h-4 rounded"
              />
              <span>Immediately block @{targetUser.handle} from feed, stories, and video calls</span>
            </label>

            <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
              <button
                type="button"
                disabled={submitting}
                onClick={handleBlockOnly}
                className="flex-1 min-h-[44px] px-4 py-2.5 border border-[#E8DEC5] hover:border-[#181510] rounded-xl text-xs font-semibold text-[#181510] flex items-center justify-center gap-1.5"
              >
                <Ban className="w-3.5 h-3.5 text-[#8B2E1E]" />
                <span>Block Only</span>
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 min-h-[44px] px-4 py-2.5 bg-[#181510] hover:bg-[#2C261D] text-white rounded-xl text-xs font-semibold"
              >
                {submitting ? 'Submitting...' : 'Submit Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
