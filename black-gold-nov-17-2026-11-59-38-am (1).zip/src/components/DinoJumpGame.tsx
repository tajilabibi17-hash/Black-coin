import { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Volume2, VolumeX, Trophy } from 'lucide-react';
import { api } from '../lib/api';
import type { UserProfile } from '../types';

interface DinoJumpGameProps {
  currentUser: UserProfile;
  onUserUpdated: (user: UserProfile) => void;
}

type GamePhase = 'TITLE' | 'PLAYING' | 'GAME_OVER';

interface Obstacle {
  x: number;
  w: number;
  h: number;
  aerial: boolean;
}

export function DinoJumpGame({ currentUser, onUserUpdated }: DinoJumpGameProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [phase, setPhase] = useState<GamePhase>('TITLE');
  const [survivalSec, setSurvivalSec] = useState(0);
  const [score, setScore] = useState(0);
  const [lastReward, setLastReward] = useState<number | null>(null);
  const [claiming, setClaiming] = useState(false);
  const [muted, setMuted] = useState(false);

  const stateRef = useRef({
    running: false,
    dinoY: 0,
    dinoVy: 0,
    ducking: false,
    jumpsRemaining: 2,
    speed: 360,
    elapsed: 0,
    spawnTimer: 1.1,
    obstacles: [] as Obstacle[],
    groundOffset: 0,
  });

  function playTone(freq: number, duration = 0.08) {
    if (muted) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Ignore audio autoplay blocks
    }
  }

  function triggerJump() {
    const s = stateRef.current;
    if (!s.running) return;
    if (s.jumpsRemaining > 0) {
      s.dinoVy = 540;
      s.jumpsRemaining -= 1;
      s.ducking = false;
      playTone(520, 0.07);
    }
  }

  function setDuck(active: boolean) {
    const s = stateRef.current;
    s.ducking = active;
    if (active && s.dinoY > 0) {
      s.dinoVy = Math.min(s.dinoVy, -420);
    }
  }

  function startRun() {
    stateRef.current = {
      running: true,
      dinoY: 0,
      dinoVy: 0,
      ducking: false,
      jumpsRemaining: 2,
      speed: 360,
      elapsed: 0,
      spawnTimer: 1.0,
      obstacles: [],
      groundOffset: 0,
    };
    setSurvivalSec(0);
    setScore(0);
    setLastReward(null);
    setPhase('PLAYING');
    playTone(660, 0.09);
  }

  async function finishRun(elapsedSeconds: number, finalScore: number) {
    setPhase('GAME_OVER');
    playTone(220, 0.18);
    if (elapsedSeconds < 0.5) return;
    setClaiming(true);
    try {
      const res = await api.submitGameReward({
        game: 'dino',
        survivalSeconds: elapsedSeconds,
        score: finalScore,
      });
      setLastReward(res.awarded);
      onUserUpdated(res.user);
    } catch {
      // Keep UI responsive
    } finally {
      setClaiming(false);
    }
  }

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (phase !== 'PLAYING') return;
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        triggerJump();
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        setDuck(true);
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        setDuck(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [phase, muted]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let lastTime = performance.now();

    const renderFrame = (now: number) => {
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cssW = canvas.clientWidth || 720;
      const cssH = canvas.clientHeight || 300;
      if (canvas.width !== Math.round(cssW * dpr) || canvas.height !== Math.round(cssH * dpr)) {
        canvas.width = Math.round(cssW * dpr);
        canvas.height = Math.round(cssH * dpr);
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      const groundY = cssH - 54;
      const s = stateRef.current;

      if (s.running) {
        s.elapsed += dt;
        s.speed = 360 + Math.min(340, s.elapsed * 7.5);
        s.groundOffset = (s.groundOffset + s.speed * dt) % 48;

        // Dino physics
        s.dinoVy -= 1550 * dt;
        s.dinoY += s.dinoVy * dt;
        if (s.dinoY <= 0) {
          s.dinoY = 0;
          s.dinoVy = 0;
          s.jumpsRemaining = 2;
        }

        // Spawn obstacles
        s.spawnTimer -= dt;
        if (s.spawnTimer <= 0) {
          const aerial = s.elapsed > 8 && Math.random() < 0.25;
          s.obstacles.push({
            x: cssW + 30,
            w: aerial ? 34 : 18 + Math.random() * 14,
            h: aerial ? 24 : 32 + Math.random() * 24,
            aerial,
          });
          const minGap = Math.max(0.65, 1.35 - s.elapsed * 0.012);
          s.spawnTimer = minGap + Math.random() * 0.65;
        }

        const dinoX = 56;
        const dinoW = s.ducking ? 42 : 30;
        const dinoH = s.ducking ? 26 : 44;
        const dinoTop = groundY - s.dinoY - dinoH;

        let collided = false;
        for (let i = s.obstacles.length - 1; i >= 0; i--) {
          const ob = s.obstacles[i];
          ob.x -= s.speed * dt;
          const obTop = ob.aerial ? groundY - 58 : groundY - ob.h;

          // Forgiving hitbox padding
          if (
            dinoX + 5 < ob.x + ob.w - 4 &&
            dinoX + dinoW - 5 > ob.x + 4 &&
            dinoTop + 5 < obTop + ob.h - 4 &&
            dinoTop + dinoH - 4 > obTop + 4
          ) {
            collided = true;
          }
          if (ob.x + ob.w < -40) {
            s.obstacles.splice(i, 1);
          }
        }

        const liveScore = Math.floor(s.elapsed * 120);
        setSurvivalSec(s.elapsed);
        setScore(liveScore);

        if (collided) {
          s.running = false;
          void finishRun(s.elapsed, liveScore);
        }
      }

      // Draw crisp white & gold canvas scene
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, cssW, cssH);

      // Subtle gold horizon grid lines
      ctx.strokeStyle = '#F2EAD5';
      ctx.lineWidth = 1;
      for (let gx = -s.groundOffset; gx < cssW; gx += 48) {
        ctx.beginPath();
        ctx.moveTo(gx, groundY);
        ctx.lineTo(gx - 20, cssH);
        ctx.stroke();
      }

      // Main runner ground line
      ctx.strokeStyle = '#C59B27';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, groundY);
      ctx.lineTo(cssW, groundY);
      ctx.stroke();

      // Draw Dino (minimalist Obsidian & Gold crest)
      const dinoX = 56;
      const dinoW = s.ducking ? 42 : 30;
      const dinoH = s.ducking ? 26 : 44;
      const dinoBottom = groundY - s.dinoY;
      const dinoTop = dinoBottom - dinoH;

      ctx.fillStyle = '#181510';
      ctx.beginPath();
      ctx.roundRect(dinoX, dinoTop, dinoW, dinoH, 6);
      ctx.fill();

      // Gold eye & dorsal accent
      ctx.fillStyle = '#D4AF37';
      ctx.fillRect(dinoX + dinoW - 9, dinoTop + 6, 4, 4);
      ctx.fillRect(dinoX + 4, dinoTop - 3, 12, 3);

      // Draw obstacles
      for (const ob of s.obstacles) {
        const obTop = ob.aerial ? groundY - 58 : groundY - ob.h;
        ctx.fillStyle = ob.aerial ? '#C59B27' : '#181510';
        ctx.beginPath();
        ctx.roundRect(ob.x, obTop, ob.w, ob.h, 4);
        ctx.fill();

        if (!ob.aerial) {
          ctx.fillStyle = '#D4AF37';
          ctx.fillRect(ob.x + 3, obTop + 3, ob.w - 6, 3);
        }
      }

      ctx.restore();
      rafId = requestAnimationFrame(renderFrame);
    };

    rafId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(rafId);
  }, []);

  const estimatedBlackTokens = Math.floor((survivalSec / 60) * 1000);

  return (
    <div className="bg-white border border-[#E8DEC5] rounded-2xl overflow-hidden">
      <div className="px-5 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="font-display text-2xl font-semibold text-[#181510]">
            Dino Jump · Line Runner
          </h3>
          <p className="text-xs text-[#6C6352]">
            1,000 Black Tokens per minute of survival · Double-jump enabled
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono-num">
          <div>
            <span className="text-[#6C6352]">Survival:</span>{' '}
            <strong className="text-[#181510]">{survivalSec.toFixed(1)}s</strong>
          </div>
          <div>
            <span className="text-[#6C6352]">Earned:</span>{' '}
            <strong className="text-[#181510]">+{estimatedBlackTokens} Black</strong>
          </div>
          <div className="hidden sm:flex items-center gap-1 text-[#997312]">
            <Trophy className="w-3.5 h-3.5" />
            <span>Best {currentUser.dinoHighScore}</span>
          </div>
          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            aria-label="Toggle sound"
            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg border border-[#E8DEC5] bg-white text-[#181510]"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <div className="relative select-none touch-manipulation">
        <canvas
          ref={canvasRef}
          onPointerDown={() => {
            if (phase === 'PLAYING') triggerJump();
          }}
          className="w-full h-[280px] sm:h-[320px] block cursor-pointer"
        />

        {phase === 'TITLE' && (
          <div className="absolute inset-0 bg-white/85 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center space-y-4">
            <h4 className="font-display text-3xl font-semibold text-[#181510]">
              Ready to Run
            </h4>
            <p className="text-xs text-[#6C6352] max-w-sm">
              Press <strong className="text-[#181510]">Space / Up</strong> or{' '}
              <strong className="text-[#181510]">Tap</strong> to jump (tap twice for double jump).
              Hold Down to duck under aerial gold drones.
            </p>
            <button
              type="button"
              onClick={startRun}
              className="min-h-[46px] px-6 py-2.5 bg-[#181510] hover:bg-[#2C261D] text-white text-sm font-semibold rounded-xl flex items-center gap-2"
            >
              <Play className="w-4 h-4 text-[#D4AF37]" />
              <span>Start Dino Jump</span>
            </button>
          </div>
        )}

        {phase === 'GAME_OVER' && (
          <div className="absolute inset-0 bg-white/90 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center space-y-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-[#997312]">
              Run Complete
            </p>
            <h4 className="font-display text-3xl font-semibold text-[#181510] font-mono-num">
              Score {score} · {survivalSec.toFixed(1)}s
            </h4>
            <p className="text-sm font-medium text-[#181510]">
              {claiming
                ? 'Crediting Black Tokens...'
                : lastReward !== null
                  ? `+${lastReward.toLocaleString()} Black Tokens credited to your Wallet`
                  : 'Survive longer than 1s to earn Black Tokens'}
            </p>
            <button
              type="button"
              onClick={startRun}
              className="min-h-[46px] px-6 py-2.5 bg-[#181510] hover:bg-[#2C261D] text-white text-sm font-semibold rounded-xl flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4 text-[#D4AF37]" />
              <span>Play Again</span>
            </button>
          </div>
        )}
      </div>

      {/* Mobile Touch Controls Bar */}
      <div className="px-5 py-3 bg-[#FBF9F4] border-t border-[#E8DEC5] flex items-center justify-between gap-3">
        <span className="text-xs text-[#6C6352]">
          Desktop: Space / Arrows · Touch: Tap buttons
        </span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onPointerDown={() => setDuck(true)}
            onPointerUp={() => setDuck(false)}
            onPointerLeave={() => setDuck(false)}
            disabled={phase !== 'PLAYING'}
            className="min-h-[44px] px-4 py-2 rounded-xl border border-[#E8DEC5] bg-white text-xs font-semibold text-[#181510] active:bg-[#F5F0E4] disabled:opacity-50"
          >
            Duck
          </button>
          <button
            type="button"
            onPointerDown={triggerJump}
            disabled={phase !== 'PLAYING'}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-[#C59B27] text-white text-xs font-semibold active:scale-95 transition-transform disabled:opacity-50"
          >
            Jump
          </button>
        </div>
      </div>
    </div>
  );
}
