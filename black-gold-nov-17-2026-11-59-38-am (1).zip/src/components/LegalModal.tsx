import { X, ShieldCheck, FileText } from 'lucide-react';

interface LegalModalProps {
  openTab: 'tos' | 'privacy' | null;
  onClose: () => void;
  onSwitchTab: (tab: 'tos' | 'privacy') => void;
}

export function LegalModal({ openTab, onClose, onSwitchTab }: LegalModalProps) {
  if (!openTab) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Legal Agreements"
    >
      <div className="w-full max-w-2xl bg-white border border-[#E8DEC5] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4]">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-white border border-[#E8DEC5] rounded-lg">
              <button
                type="button"
                onClick={() => onSwitchTab('tos')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  openTab === 'tos'
                    ? 'bg-[#C59B27] text-white'
                    : 'text-[#6C6352] hover:text-[#181510]'
                }`}
              >
                Terms of Service
              </button>
              <button
                type="button"
                onClick={() => onSwitchTab('privacy')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  openTab === 'privacy'
                    ? 'bg-[#C59B27] text-white'
                    : 'text-[#6C6352] hover:text-[#181510]'
                }`}
              >
                Privacy Policy
              </button>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close legal dialog"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-[#6C6352] hover:text-[#181510] hover:bg-[#F5F0E4] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5 text-sm leading-relaxed text-[#3B3429]">
          {openTab === 'tos' ? (
            <>
              <div className="flex items-center gap-2 text-[#181510]">
                <FileText className="w-5 h-5 text-[#C59B27]" />
                <h2 className="font-display text-2xl font-semibold">
                  Black Gold Terms of Service
                </h2>
              </div>
              <p className="text-xs text-[#6C6352]">
                Effective Date: November 2026 · Applies across Web, Android, and iOS clients.
              </p>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">1. Eligibility &amp; 12+ Video Calling</h3>
                <p>
                  Random video calling on Black Gold is strictly restricted to individuals aged 12
                  years and older. Accounts registering under age 12 are programmatically barred
                  from entering video matchmaking queues. Misrepresenting age is grounds for
                  immediate termination.
                </p>
              </section>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">
                  2. AI Call Moderation &amp; 24-Hour Suspension Enforcement
                </h3>
                <p>
                  To protect our community, live video call streams and call chat messages undergo
                  automated AI safety evaluation. Inappropriate content—including nudity, sexual
                  conduct, violence, hate speech, harassment, or underage endangerment—triggers
                  immediate call termination and automatic account suspension within 24 hours.
                </p>
              </section>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">
                  3. Dual-Currency Economy (Black Coins &amp; Gold Coins)
                </h3>
                <p>
                  Black Coins (Black Tokens) and Gold Coins are platform-native virtual rewards with
                  no cash or legal-tender value. One (1) Gold Coin equals ten (10) Black Coins.
                  Daily 365-day login rewards (1,000 Gold Coins/day), mini-game survival payouts
                  (Dino Jump: 1,000 Black Tokens/min; Gold Rush Runner: 100 Gold Coins/min), and
                  peer-to-peer transfers are final once committed to the ledger.
                </p>
              </section>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">4. Reporting &amp; Blocking</h3>
                <p>
                  Users may block or report any member from profiles, stories, or active video
                  calls. Blocked members are immediately excluded from your social feed, stories,
                  transfers, and random video call matching.
                </p>
              </section>
            </>
          ) : (
            <>
              <div className="flex items-center gap-2 text-[#181510]">
                <ShieldCheck className="w-5 h-5 text-[#C59B27]" />
                <h2 className="font-display text-2xl font-semibold">
                  Black Gold Privacy Policy
                </h2>
              </div>
              <p className="text-xs text-[#6C6352]">
                Effective Date: November 2026 · Zero-Sale Data Commitment.
              </p>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">1. Profile &amp; Media Information</h3>
                <p>
                  We store your chosen display name, handle, age bracket, gender filter preference,
                  display picture (DP), and 24-hour stories solely to power social discovery and
                  filter-matched video calling. Stories automatically expire after 24 hours.
                </p>
              </section>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">
                  2. Live Video &amp; AI Safety Processing
                </h3>
                <p>
                  Video and audio streams use peer-to-peer WebRTC transport. Periodic low-resolution
                  safety snapshots or call text snippets may be analyzed transiently by our AI
                  moderation service solely to detect policy violations. Safe frames are discarded
                  immediately without permanent archival.
                </p>
              </section>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">3. Push Notifications &amp; Controls</h3>
                <p>
                  With your explicit permission, Black Gold sends push alerts for incoming
                  peer-to-peer coin transfers, new followers, daily 1,000 Gold Coin streak
                  milestones, and safety notices. You may revoke notification permissions in your
                  browser or device settings at any time.
                </p>
              </section>

              <section className="space-y-1.5">
                <h3 className="font-semibold text-[#181510]">4. User Rights &amp; Safety Records</h3>
                <p>
                  You control your block list and profile visibility at all times. Safety reports
                  and moderation logs are retained exclusively to enforce platform integrity and
                  prevent repeat abuse across Android, iOS, and Web.
                </p>
              </section>
            </>
          )}
        </div>

        <div className="px-6 py-4 border-t border-[#E8DEC5] bg-[#FBF9F4] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 text-sm font-semibold bg-[#181510] text-white rounded-lg hover:bg-[#2C261D] transition-colors whitespace-nowrap shrink-0"
          >
            Acknowledge &amp; Close
          </button>
        </div>
      </div>
    </div>
  );
}
