import React, { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Trophy, ArrowLeft, ArrowRight, ArrowUp, ArrowDown } from 'lucide-react';
import { api } from '../lib/api';
import type { UserProfile } from '../types';

interface GoldRunnerGameProps {
  currentUser: UserProfile;
  onUserUpdated: (user: UserProfile) => void;
}

type RunnerPhase = 'TITLE' | 'PLAYING' | 'GAME_OVER';

interface TrackEntity {
  lane: number; // 0, 1, 2
  z: number; // 1.0 (horizon) -> 0.0 (player)
  kind: 'barrier_low' | 'barrier_tall' | 'gate_high' | 'coin';
  collected?: boolean;
}

export function GoldRunnerGame({ currentUser, onUserUpdated }: GoldRunnerGameProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [phase, setPhase] = useState<RunnerPhase>('TITLE');
  const [survivalSec, setSurvivalSec] = useState(0);
  const [pickupCoins, setPickupCoins] = useState(0);
  const [score, setScore] = useState(0);
  const [lastReward, setLastReward] = useState<number | null>(null);
  const [claiming, setClaiming] = useState(false);

  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  const stateRef = useRef({
    running: false,
    lane: 1,
    visualLane: 1,
    jumpHeight: 0,
    jumpVy: 0,
    slideTimer: 0,
    elapsed: 0,
    speed: 0.42, // z units per second
    spawnTimer: 0.7,
    entities: [] as TrackEntity[],
    pickups: 0,
    trackScroll: 0,
  });

  function moveLane(delta: -1 | 1) {
    const s = stateRef.current;
    if (!s.running) return;
    s.lane = Math.max(0, Math.min(2, s.lane + delta));
  }

  function triggerJump() {
    const s = stateRef.current;
    if (!s.running) return;
    if (s.jumpHeight <= 0.01) {
      s.jumpVy = 2.6;
      s.slideTimer = 0;
    }
  }

  function triggerSlide() {
    const s = stateRef.current;
    if (!s.running) return;
    s.slideTimer = 0.65;
    if (s.jumpHeight > 0) {
      s.jumpVy = -3.5;
    }
  }

  function startRun() {
    stateRef.current = {
      running: true,
      lane: 1,
      visualLane: 1,
      jumpHeight: 0,
      jumpVy: 0,
      slideTimer: 0,
      elapsed: 0,
      speed: 0.44,
      spawnTimer: 0.55,
      entities: [],
      pickups: 0,
      trackScroll: 0,
    };
    setSurvivalSec(0);
    setPickupCoins(0);
    setScore(0);
    setLastReward(null);
    setPhase('PLAYING');
  }

  async function finishRun(elapsedSeconds: number, finalScore: number, coinsCollected: number) {
    setPhase('GAME_OVER');
    if (elapsedSeconds < 0.5) return;
    setClaiming(true);
    try {
      const res = await api.submitGameReward({
        game: 'runner',
        survivalSeconds: elapsedSeconds,
        score: finalScore,
        pickupCoins: coinsCollected,
      });
      setLastReward(res.awarded);
      onUserUpdated(res.user);
    } catch {
      // Keep playable on transient network hiccup
    } finally {
      setClaiming(false);
    }
  }

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (phase !== 'PLAYING') return;
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') {
        e.preventDefault();
        moveLane(-1);
      } else if (e.code === 'ArrowRight' || e.code === 'KeyD') {
        e.preventDefault();
        moveLane(1);
      } else if (e.code === 'ArrowUp' || e.code === 'KeyW' || e.code === 'Space') {
        e.preventDefault();
        triggerJump();
      } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        triggerSlide();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [phase]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let lastTime = performance.now();

    const renderFrame = (now: number) => {
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cssW = canvas.clientWidth || 720;
      const cssH = canvas.clientHeight || 340;
      if (canvas.width !== Math.round(cssW * dpr) || canvas.height !== Math.round(cssH * dpr)) {
        canvas.width = Math.round(cssW * dpr);
        canvas.height = Math.round(cssH * dpr);
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      const s = stateRef.current;

      if (s.running) {
        s.elapsed += dt;
        s.speed = 0.44 + Math.min(0.45, s.elapsed * 0.008);
        s.trackScroll = (s.trackScroll + s.speed * dt * 8) % 1;
        s.visualLane += (s.lane - s.visualLane) * Math.min(1, dt * 16);

        if (s.slideTimer > 0) {
          s.slideTimer = Math.max(0, s.slideTimer - dt);
        }

        s.jumpVy -= 7.2 * dt;
        s.jumpHeight = Math.max(0, s.jumpHeight + s.jumpVy * dt);
        if (s.jumpHeight === 0) s.jumpVy = 0;

        s.spawnTimer -= dt;
        if (s.spawnTimer <= 0) {
          const lane = Math.floor(Math.random() * 3);
          const roll = Math.random();
          if (roll < 0.42) {
            // Spawn a 3-coin line in a lane
            for (let k = 0; k < 3; k++) {
              s.entities.push({ lane, z: 1.0 + k * 0.07, kind: 'coin' });
            }
          } else {
            const kinds: TrackEntity['kind'][] = ['barrier_low', 'barrier_tall', 'gate_high'];
            const kind = kinds[Math.floor(Math.random() * kinds.length)];
            s.entities.push({ lane, z: 1.0, kind });
            // Add a coin in an adjacent safe lane
            const safeLane = (lane + 1) % 3;
            s.entities.push({ lane: safeLane, z: 1.0, kind: 'coin' });
          }
          s.spawnTimer = Math.max(0.42, 0.85 - s.elapsed * 0.007);
        }

        let crashed = false;
        for (let i = s.entities.length - 1; i >= 0; i--) {
          const ent = s.entities[i];
          ent.z -= s.speed * dt;

          if (ent.z <= 0.09 && ent.z >= 0.01 && Math.abs(s.visualLane - ent.lane) < 0.42) {
            if (ent.kind === 'coin') {
              if (!ent.collected) {
                ent.collected = true;
                s.pickups += 1;
                setPickupCoins(s.pickups);
              }
            } else if (ent.kind === 'barrier_low') {
              if (s.jumpHeight < 0.25) crashed = true;
            } else if (ent.kind === 'gate_high') {
              if (s.slideTimer <= 0) crashed = true;
            } else if (ent.kind === 'barrier_tall') {
              crashed = true;
            }
          }

          if (ent.z < -0.05 || ent.collected) {
            s.entities.splice(i, 1);
          }
        }

        const liveScore = Math.floor(s.elapsed * 100 + s.pickups * 25);
        setSurvivalSec(s.elapsed);
        setScore(liveScore);

        if (crashed) {
          s.running = false;
          void finishRun(s.elapsed, liveScore, s.pickups);
        }
      }

      // Draw crisp White & Gold 3-lane perspective corridor
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, cssW, cssH);

      const horizonY = cssH * 0.26;
      const bottomY = cssH - 18;
      const centerX = cssW / 2;
      const topHalfW = cssW * 0.12;
      const botHalfW = cssW * 0.42;

      // Subtle ivory track bed
      ctx.fillStyle = '#FBF9F4';
      ctx.beginPath();
      ctx.moveTo(centerX - topHalfW, horizonY);
      ctx.lineTo(centerX + topHalfW, horizonY);
      ctx.lineTo(centerX + botHalfW, bottomY);
      ctx.lineTo(centerX - botHalfW, bottomY);
      ctx.closePath();
      ctx.fill();

      // Perspective helper: laneIndex in [-1, 0, 1] (left, center, right) & depth z in [0..1] (0=bottom, 1=horizon)
      const project = (laneFloat: number, z: number) => {
        const clampedZ = Math.max(0, Math.min(1.15, z));
        const t = 1 - clampedZ; // 0 at horizon, 1 at player
        const ease = t * t * 0.65 + t * 0.35;
        const y = horizonY + (bottomY - horizonY) * ease;
        const halfW = topHalfW + (botHalfW - topHalfW) * ease;
        const laneOffset = (laneFloat - 1) * (halfW * 0.66);
        const scale = 0.25 + 0.9 * ease;
        return { x: centerX + laneOffset, y, halfW, scale };
      };

      // Draw gold lane rails
      ctx.strokeStyle = '#DFD1AE';
      ctx.lineWidth = 1.5;
      for (const edge of [-1.5, -0.5, 0.5, 1.5]) {
        const pTop = project(1 + edge * 0.95, 1);
        const pBot = project(1 + edge * 0.95, 0);
        ctx.beginPath();
        ctx.moveTo(pTop.x, pTop.y);
        ctx.lineTo(pBot.x, pBot.y);
        ctx.stroke();
      }

      // Moving sleeper ties
      ctx.strokeStyle = '#EFE7D2';
      ctx.lineWidth = 1.5;
      for (let step = 0; step < 8; step++) {
        const z = ((step / 8) + (1 - s.trackScroll / 8)) % 1;
        const p = project(1, z);
        ctx.beginPath();
        ctx.moveTo(centerX - p.halfW, p.y);
        ctx.lineTo(centerX + p.halfW, p.y);
        ctx.stroke();
      }

      // Horizon rule
      ctx.strokeStyle = '#C59B27';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, horizonY);
      ctx.lineTo(cssW, horizonY);
      ctx.stroke();

      // Sort entities far-to-near for proper painter's order
      const sorted = [...s.entities].sort((a, b) => b.z - a.z);
      for (const ent of sorted) {
        if (ent.z > 1.02) continue;
        const p = project(ent.lane, ent.z);
        if (ent.kind === 'coin') {
          const r = 11 * p.scale;
          ctx.fillStyle = '#D4AF37';
          ctx.beginPath();
          ctx.arc(p.x, p.y - 16 * p.scale, r, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#997312';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        } else if (ent.kind === 'barrier_low') {
          const w = 52 * p.scale;
          const h = 24 * p.scale;
          ctx.fillStyle = '#181510';
          ctx.beginPath();
          ctx.roundRect(p.x - w / 2, p.y - h, w, h, 4);
          ctx.fill();
          ctx.fillStyle = '#D4AF37';
          ctx.fillRect(p.x - w / 2 + 4, p.y - h + 4, w - 8, 4 * p.scale);
        } else if (ent.kind === 'barrier_tall') {
          const w = 50 * p.scale;
          const h = 64 * p.scale;
          ctx.fillStyle = '#181510';
          ctx.beginPath();
          ctx.roundRect(p.x - w / 2, p.y - h, w, h, 5);
          ctx.fill();
          ctx.fillStyle = '#D4AF37';
          ctx.fillRect(p.x - w / 2 + 4, p.y - h + 6, w - 8, 5 * p.scale);
        } else if (ent.kind === 'gate_high') {
          const w = 56 * p.scale;
          const h = 24 * p.scale;
          const lift = 34 * p.scale;
          ctx.fillStyle = '#C59B27';
          ctx.beginPath();
          ctx.roundRect(p.x - w / 2, p.y - lift - h, w, h, 4);
          ctx.fill();
          // Gate posts
          ctx.fillStyle = '#181510';
          ctx.fillRect(p.x - w / 2, p.y - lift - h, 4 * p.scale, lift + h);
          ctx.fillRect(p.x + w / 2 - 4 * p.scale, p.y - lift - h, 4 * p.scale, lift + h);
        }
      }

      // Draw Player Runner
      const playerPos = project(s.visualLane, 0.05);
      const isSliding = s.slideTimer > 0;
      const pW = isSliding ? 34 : 26;
      const pH = isSliding ? 22 : 46;
      const pLift = s.jumpHeight * 70;
      const px = playerPos.x - pW / 2;
      const py = playerPos.y - pH - pLift;

      // Ground shadow
      ctx.fillStyle = 'rgba(24, 21, 16, 0.14)';
      ctx.beginPath();
      ctx.ellipse(playerPos.x, playerPos.y, 16, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Runner torso
      ctx.fillStyle = '#181510';
      ctx.beginPath();
      ctx.roundRect(px, py, pW, pH, 8);
      ctx.fill();

      // Gold trim visor
      ctx.fillStyle = '#D4AF37';
      ctx.fillRect(px + 4, py + 6, pW - 8, 5);

      ctx.restore();
      rafId = requestAnimationFrame(renderFrame);
    };

    rafId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(rafId);
  }, []);

  function handleTouchStart(e: React.TouchEvent) {
    const t = e.touches[0];
    touchStartRef.current = { x: t.clientX, y: t.clientY };
  }

  function handleTouchEnd(e: React.TouchEvent) {
    if (!touchStartRef.current || phase !== 'PLAYING') return;
    const t = e.changedTouches[0];
    const dx = t.clientX - touchStartRef.current.x;
    const dy = t.clientY - touchStartRef.current.y;
    touchStartRef.current = null;

    if (Math.abs(dx) > Math.abs(dy)) {
      if (dx > 24) moveLane(1);
      else if (dx < -24) moveLane(-1);
    } else {
      if (dy < -24) triggerJump();
      else if (dy > 24) triggerSlide();
    }
  }

  const estimatedGold = Math.floor((survivalSec / 60) * 100) + pickupCoins;

  return (
    <div className="bg-white border border-[#E8DEC5] rounded-2xl overflow-hidden">
      <div className="px-5 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="font-display text-2xl font-semibold text-[#181510]">
            Gold Rush Runner · 3-Lane Endless
          </h3>
          <p className="text-xs text-[#6C6352]">
            100 Gold Coins per minute of survival + Gold Coin pickups on the tracks
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono-num">
          <div>
            <span className="text-[#6C6352]">Time:</span>{' '}
            <strong className="text-[#181510]">{survivalSec.toFixed(1)}s</strong>
          </div>
          <div>
            <span className="text-[#6C6352]">Pickups:</span>{' '}
            <strong className="text-[#997312]">{pickupCoins}</strong>
          </div>
          <div>
            <span className="text-[#6C6352]">Payout:</span>{' '}
            <strong className="text-[#997312]">+{estimatedGold} Gold</strong>
          </div>
          <div className="hidden sm:flex items-center gap-1 text-[#181510]">
            <Trophy className="w-3.5 h-3.5 text-[#C59B27]" />
            <span>Best {currentUser.runnerHighScore}</span>
          </div>
        </div>
      </div>

      <div
        className="relative select-none touch-none"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <canvas ref={canvasRef} className="w-full h-[300px] sm:h-[340px] block" />

        {phase === 'TITLE' && (
          <div className="absolute inset-0 bg-white/85 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center space-y-4">
            <h4 className="font-display text-3xl font-semibold text-[#181510]">
              3-Lane Gold Express
            </h4>
            <p className="text-xs text-[#6C6352] max-w-sm">
              Swipe or use <strong className="text-[#181510]">Arrow Keys / WASD</strong> to switch
              lanes, jump low black barriers, and slide under high gold gates.
            </p>
            <button
              type="button"
              onClick={startRun}
              className="min-h-[46px] px-6 py-2.5 bg-[#C59B27] hover:bg-[#B0871B] text-white text-sm font-semibold rounded-xl flex items-center gap-2"
            >
              <Play className="w-4 h-4" />
              <span>Start Gold Runner</span>
            </button>
          </div>
        )}

        {phase === 'GAME_OVER' && (
          <div className="absolute inset-0 bg-white/90 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center space-y-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-[#997312]">
              Run Complete
            </p>
            <h4 className="font-display text-3xl font-semibold text-[#181510] font-mono-num">
              Score {score} · {survivalSec.toFixed(1)}s
            </h4>
            <p className="text-sm font-medium text-[#181510]">
              {claiming
                ? 'Crediting Gold Coins...'
                : lastReward !== null
                  ? `+${lastReward.toLocaleString()} Gold Coins credited to your Wallet`
                  : 'Survive longer than 1s to earn Gold Coins'}
            </p>
            <button
              type="button"
              onClick={startRun}
              className="min-h-[46px] px-6 py-2.5 bg-[#C59B27] hover:bg-[#B0871B] text-white text-sm font-semibold rounded-xl flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Run Again</span>
            </button>
          </div>
        )}
      </div>

      {/* Responsive Touch Controls for iOS/Android */}
      <div className="px-5 py-3 bg-[#FBF9F4] border-t border-[#E8DEC5] flex items-center justify-between gap-2">
        <span className="hidden sm:inline text-xs text-[#6C6352]">
          Swipe on track or use Arrow keys / WASD
        </span>
        <div className="flex items-center gap-2 w-full sm:w-auto justify-center">
          <button
            type="button"
            disabled={phase !== 'PLAYING'}
            onPointerDown={() => moveLane(-1)}
            aria-label="Move Left"
            className="min-h-[44px] min-w-[48px] px-3 rounded-xl border border-[#E8DEC5] bg-white flex items-center justify-center text-[#181510] active:bg-[#F5F0E4] disabled:opacity-50"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            disabled={phase !== 'PLAYING'}
            onPointerDown={triggerJump}
            aria-label="Jump"
            className="min-h-[44px] px-4 rounded-xl bg-[#C59B27] text-white text-xs font-semibold flex items-center gap-1 active:scale-95 disabled:opacity-50"
          >
            <ArrowUp className="w-4 h-4" />
            <span>Jump</span>
          </button>
          <button
            type="button"
            disabled={phase !== 'PLAYING'}
            onPointerDown={triggerSlide}
            aria-label="Slide"
            className="min-h-[44px] px-4 rounded-xl border border-[#E8DEC5] bg-white text-xs font-semibold text-[#181510] flex items-center gap-1 active:bg-[#F5F0E4] disabled:opacity-50"
          >
            <ArrowDown className="w-4 h-4" />
            <span>Slide</span>
          </button>
          <button
            type="button"
            disabled={phase !== 'PLAYING'}
            onPointerDown={() => moveLane(1)}
            aria-label="Move Right"
            className="min-h-[44px] min-w-[48px] px-3 rounded-xl border border-[#E8DEC5] bg-white flex items-center justify-center text-[#181510] active:bg-[#F5F0E4] disabled:opacity-50"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
