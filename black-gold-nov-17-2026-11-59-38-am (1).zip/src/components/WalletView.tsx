import React, { useEffect, useState } from 'react';
import { Coins, ArrowLeftRight, Send, CalendarCheck2, Flame } from 'lucide-react';
import { api } from '../lib/api';
import type { CoinTransaction, CurrencyType, UserProfile } from '../types';

interface WalletViewProps {
  currentUser: UserProfile;
  users: UserProfile[];
  prefillRecipient?: string;
  onUserUpdated: (user: UserProfile) => void;
}

export function WalletView({
  currentUser,
  users,
  prefillRecipient,
  onUserUpdated,
}: WalletViewProps) {
  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  const [direction, setDirection] = useState<'gold_to_black' | 'black_to_gold'>('gold_to_black');
  const [convertAmount, setConvertAmount] = useState('10');
  const [recipientHandle, setRecipientHandle] = useState(prefillRecipient || '');
  const [transferCurrency, setTransferCurrency] = useState<CurrencyType>('gold');
  const [transferAmount, setTransferAmount] = useState('25');
  const [transferNote, setTransferNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    if (prefillRecipient) {
      setRecipientHandle(prefillRecipient);
    }
  }, [prefillRecipient]);

  async function loadTransactions() {
    try {
      const res = await api.listTransactions();
      setTransactions(res.transactions);
    } catch {
      // Ignore transient errors
    }
  }

  useEffect(() => {
    void loadTransactions();
  }, [currentUser.goldCoins, currentUser.blackCoins]);

  const alreadyClaimedToday = (() => {
    if (!currentUser.lastDailyClaimAt) return false;
    const last = new Date(currentUser.lastDailyClaimAt);
    const now = new Date();
    return (
      last.getUTCFullYear() === now.getUTCFullYear() &&
      last.getUTCMonth() === now.getUTCMonth() &&
      last.getUTCDate() === now.getUTCDate()
    );
  })();

  async function handleClaimDaily() {
    setBusy(true);
    setFeedback(null);
    try {
      const res = await api.claimDailyGold();
      onUserUpdated(res.user);
      setFeedback({
        type: 'ok',
        text: `Day ${res.user.streakDays}/365 claimed: +1,000 Gold Coins credited!`,
      });
      await loadTransactions();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Claim failed',
      });
    } finally {
      setBusy(false);
    }
  }

  async function handleConvert(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setFeedback(null);
    try {
      const qty = Math.floor(Number(convertAmount));
      const res = await api.convertCoins(direction, qty);
      onUserUpdated(res.user);
      setFeedback({ type: 'ok', text: res.transaction.note });
      await loadTransactions();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Conversion failed',
      });
    } finally {
      setBusy(false);
    }
  }

  async function handleTransfer(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setFeedback(null);
    try {
      const res = await api.transferCoins({
        recipientHandle,
        currency: transferCurrency,
        amount: Math.floor(Number(transferAmount)),
        note: transferNote,
      });
      onUserUpdated(res.user);
      setFeedback({ type: 'ok', text: `Sent ${transferAmount} ${transferCurrency} coins to @${recipientHandle.replace(/^@/, '')}` });
      setTransferNote('');
      await loadTransactions();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Transfer failed',
      });
    } finally {
      setBusy(false);
    }
  }

  const qtyPreview = Math.max(0, Math.floor(Number(convertAmount) || 0));
  const convertedOutput =
    direction === 'gold_to_black' ? qtyPreview * 10 : Math.floor(qtyPreview / 10);

  return (
    <div className="space-y-6">
      {feedback && (
        <div
          className={`px-4 py-3 rounded-xl border text-xs font-medium ${
            feedback.type === 'ok'
              ? 'bg-[#FBF9F4] border-[#C59B27] text-[#181510]'
              : 'bg-[#FDF4F2] border-[#E5B8B0] text-[#8B2E1E]'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {/* Dual-Currency Balances & 365-Day Daily Streak */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-white border border-[#E8DEC5] rounded-2xl p-6 flex flex-col justify-between gap-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-[#997312]">
              Dual-Currency Treasury
            </p>
            <h2 className="font-display text-3xl font-semibold text-[#181510] mt-1">
              Black &amp; Gold Wallet
            </h2>
            <p className="text-xs text-[#6C6352] mt-1">
              Fixed Exchange Parity: 1 Gold Coin = 10 Black Coins
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#FBF9F4] border border-[#E8DEC5]">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#997312]">
                <Coins className="w-4 h-4" />
                <span>Gold Coins</span>
              </div>
              <p className="font-mono-num text-2xl sm:text-3xl font-semibold text-[#181510] mt-2">
                {currentUser.goldCoins.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#181510] text-white">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#D4AF37]">
                <Coins className="w-4 h-4" />
                <span>Black Coins</span>
              </div>
              <p className="font-mono-num text-2xl sm:text-3xl font-semibold mt-2">
                {currentUser.blackCoins.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        {/* 365-Day Daily Reward */}
        <div className="lg:col-span-7 bg-[#FBF9F4] border border-[#E8DEC5] rounded-2xl p-6 flex flex-col justify-between gap-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-[#997312]">
                <Flame className="w-4 h-4" />
                <span>365-Day Daily Login Reward</span>
              </div>
              <h3 className="font-display text-2xl font-semibold text-[#181510] mt-1">
                1,000 Gold Coins Every Day
              </h3>
              <p className="text-xs text-[#6C6352] mt-1 font-mono-num">
                Streak: Day {currentUser.streakDays} / 365 · Total Claimed:{' '}
                {currentUser.totalDailyGoldClaimed.toLocaleString()} Gold
              </p>
            </div>

            <button
              type="button"
              disabled={busy || alreadyClaimedToday || currentUser.streakDays >= 365}
              onClick={handleClaimDaily}
              className="min-h-[46px] px-5 py-2.5 rounded-xl bg-[#C59B27] hover:bg-[#B0871B] text-white text-xs font-semibold flex items-center justify-center gap-2 whitespace-nowrap disabled:opacity-50"
            >
              <CalendarCheck2 className="w-4 h-4" />
              <span>
                {alreadyClaimedToday ? 'Claimed Today' : 'Claim 1,000 Gold'}
              </span>
            </button>
          </div>

          {/* 365-Day Progress Track */}
          <div className="space-y-2">
            <div className="h-2.5 w-full rounded-full bg-white border border-[#E8DEC5] overflow-hidden">
              <div
                className="h-full gold-shimmer transition-all duration-300"
                style={{ width: `${Math.min(100, (currentUser.streakDays / 365) * 100)}%` }}
              />
            </div>
            <div className="grid grid-cols-7 sm:grid-cols-14 gap-1.5 pt-1">
              {Array.from({ length: 14 }).map((_, i) => {
                const cycleDay = Math.floor(currentUser.streakDays / 14) * 14 + i + 1;
                const claimed = cycleDay <= currentUser.streakDays;
                return (
                  <div
                    key={cycleDay}
                    className={`py-1.5 rounded-lg text-center text-[10px] font-mono-num font-semibold border ${
                      claimed
                        ? 'bg-[#181510] text-[#D4AF37] border-[#181510]'
                        : 'bg-white text-[#6C6352] border-[#E8DEC5]'
                    }`}
                  >
                    D{cycleDay}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Converter + Peer-to-Peer Transfer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <form
          onSubmit={handleConvert}
          className="bg-white border border-[#E8DEC5] rounded-2xl p-6 space-y-4"
        >
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-[#C59B27]" />
            <h3 className="font-display text-2xl font-semibold text-[#181510]">
              Convert Currency
            </h3>
          </div>

          <div className="flex items-center gap-1 p-1 bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg">
            <button
              type="button"
              onClick={() => setDirection('gold_to_black')}
              className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors ${
                direction === 'gold_to_black'
                  ? 'bg-[#C59B27] text-white'
                  : 'text-[#6C6352] hover:text-[#181510]'
              }`}
            >
              Gold → Black (1:10)
            </button>
            <button
              type="button"
              onClick={() => setDirection('black_to_gold')}
              className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors ${
                direction === 'black_to_gold'
                  ? 'bg-[#181510] text-white'
                  : 'text-[#6C6352] hover:text-[#181510]'
              }`}
            >
              Black → Gold (10:1)
            </button>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181510] mb-1.5">
              Amount to Convert ({direction === 'gold_to_black' ? 'Gold Coins' : 'Black Coins (multiples of 10)'})
            </label>
            <input
              type="number"
              min={direction === 'gold_to_black' ? 1 : 10}
              step={direction === 'gold_to_black' ? 1 : 10}
              required
              value={convertAmount}
              onChange={(e) => setConvertAmount(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm font-mono-num bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
            />
          </div>

          <div className="px-4 py-3 rounded-xl bg-[#FBF9F4] border border-[#E8DEC5] flex items-center justify-between text-xs">
            <span className="text-[#6C6352]">You Will Receive</span>
            <strong className="font-mono-num text-sm text-[#181510]">
              {convertedOutput.toLocaleString()}{' '}
              {direction === 'gold_to_black' ? 'Black Coins' : 'Gold Coins'}
            </strong>
          </div>

          <button
            type="submit"
            disabled={busy}
            className="w-full min-h-[44px] bg-[#181510] hover:bg-[#2C261D] text-white text-xs font-semibold rounded-xl"
          >
            Convert Instantly
          </button>
        </form>

        <form
          onSubmit={handleTransfer}
          className="bg-white border border-[#E8DEC5] rounded-2xl p-6 space-y-4"
        >
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-[#C59B27]" />
            <h3 className="font-display text-2xl font-semibold text-[#181510]">
              Peer-to-Peer Coin Transfer
            </h3>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181510] mb-1.5">
              Recipient Handle
            </label>
            <input
              type="text"
              required
              list="member-handles"
              value={recipientHandle}
              onChange={(e) => setRecipientHandle(e.target.value)}
              placeholder="sophia"
              className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
            />
            <datalist id="member-handles">
              {users.map((u) => (
                <option key={u.id} value={u.handle}>
                  {u.displayName} (@{u.handle})
                </option>
              ))}
            </datalist>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                Currency
              </label>
              <select
                value={transferCurrency}
                onChange={(e) => setTransferCurrency(e.target.value as CurrencyType)}
                className="w-full px-3 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
              >
                <option value="gold">Gold Coins</option>
                <option value="black">Black Coins</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#181510] mb-1.5">
                Amount
              </label>
              <input
                type="number"
                min={1}
                required
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm font-mono-num bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181510] mb-1.5">
              Note (optional)
            </label>
            <input
              type="text"
              value={transferNote}
              onChange={(e) => setTransferNote(e.target.value)}
              placeholder="Thanks for the match!"
              maxLength={80}
              className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#E8DEC5] rounded-xl focus:outline-none focus:border-[#C59B27]"
            />
          </div>

          <button
            type="submit"
            disabled={busy}
            className="w-full min-h-[44px] bg-[#C59B27] hover:bg-[#B0871B] text-white text-xs font-semibold rounded-xl"
          >
            Send Peer Transfer
          </button>
        </form>
      </div>

      {/* Transaction Ledger */}
      <div className="bg-white border border-[#E8DEC5] rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4]">
          <h3 className="font-display text-2xl font-semibold text-[#181510]">
            Wallet Ledger
          </h3>
        </div>
        {transactions.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#6C6352]">
            No transactions recorded yet. Claim your daily 1,000 Gold Coins or play a mini-game.
          </div>
        ) : (
          <div className="divide-y divide-[#F0E9D6]">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="px-6 py-3.5 flex items-center justify-between gap-4 text-xs"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-[#181510] truncate">{tx.note}</p>
                  <p className="text-[#6C6352] mt-0.5 font-mono-num">
                    {new Date(tx.createdAt).toLocaleString()}
                  </p>
                </div>
                <span
                  className={`font-mono-num font-semibold shrink-0 ${
                    tx.currency === 'gold' ? 'text-[#997312]' : 'text-[#181510]'
                  }`}
                >
                  {tx.fromUserId === currentUser.id && tx.type === 'p2p_transfer' ? '-' : '+'}
                  {tx.amount.toLocaleString()} {tx.currency === 'gold' ? 'Gold' : 'Black'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
