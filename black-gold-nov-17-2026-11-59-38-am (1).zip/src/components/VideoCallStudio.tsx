import React, { useEffect, useRef, useState } from 'react';
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  PhoneOff,
  ShieldCheck,
  ShieldAlert,
  Flag,
  Send,
  Camera,
  Sparkles,
  Lock,
} from 'lucide-react';
import { api } from '../lib/api';
import type { GenderFilter, ModerationAnalysisResult, UserProfile } from '../types';

interface VideoCallStudioProps {
  currentUser: UserProfile;
  ws: WebSocket | null;
  wsConnected: boolean;
  onUserUpdated: (user: UserProfile) => void;
  onOpenReportModal: (user: UserProfile, context: 'video_call') => void;
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
};

export function VideoCallStudio({
  currentUser,
  ws,
  wsConnected,
  onUserUpdated,
  onOpenReportModal,
}: VideoCallStudioProps) {
  const [genderFilter, setGenderFilter] = useState<GenderFilter>('all');
  const [callState, setCallState] = useState<'idle' | 'queued' | 'connected'>('idle');
  const [queueSize, setQueueSize] = useState(0);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [peer, setPeer] = useState<UserProfile | null>(null);

  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<
    Array<{ id: string; sender: 'you' | 'peer'; text: string }>
  >([]);

  const [aiStatus, setAiStatus] = useState<ModerationAnalysisResult | null>(null);
  const [aiScanning, setAiScanning] = useState(false);
  const [safetyTestInput, setSafetyTestInput] = useState('');

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const roomIdRef = useRef<string | null>(null);

  roomIdRef.current = roomId;

  const isUnder12 = currentUser.age < 12;
  const isSuspended = currentUser.moderationStatus !== 'active';

  async function ensureLocalMedia(): Promise<MediaStream | null> {
    if (localStreamRef.current) return localStreamRef.current;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setMediaError('Camera/microphone API is unavailable in this browser.');
      return null;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        audio: true,
      });
      localStreamRef.current = stream;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }
      setMediaError(null);
      return stream;
    } catch {
      setMediaError(
        'Camera or microphone permission was denied. You can still test signaling, chat, and AI text moderation.'
      );
      return null;
    }
  }

  function cleanupPeerConnection() {
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
  }

  function stopLocalMedia() {
    if (localStreamRef.current) {
      for (const track of localStreamRef.current.getTracks()) {
        track.stop();
      }
      localStreamRef.current = null;
    }
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
  }

  useEffect(() => {
    return () => {
      cleanupPeerConnection();
      stopLocalMedia();
    };
  }, []);

  useEffect(() => {
    if (!ws) return;

    const handleMessage = async (event: MessageEvent) => {
      try {
        const msg = JSON.parse(event.data as string) as {
          type: string;
          roomId?: string;
          isInitiator?: boolean;
          peer?: UserProfile;
          queueSize?: number;
          payload?: RTCSessionDescriptionInit | RTCIceCandidateInit;
          text?: string;
          error?: string;
          reason?: string;
        };

        if (msg.type === 'call:queued') {
          setCallState('queued');
          setQueueSize(msg.queueSize || 1);
          setStatusNotice('Searching for a verified 12+ match matching your filter...');
          return;
        }

        if (msg.type === 'call:left_queue') {
          setCallState('idle');
          setStatusNotice(null);
          return;
        }

        if (msg.type === 'call:rejected') {
          setCallState('idle');
          setStatusNotice(msg.error || 'Call request blocked by safety policy.');
          return;
        }

        if (msg.type === 'call:matched' && msg.roomId && msg.peer) {
          setRoomId(msg.roomId);
          setPeer(msg.peer);
          setCallState('connected');
          setChatMessages([]);
          setStatusNotice(`Connected with @${msg.peer.handle}`);

          const stream = await ensureLocalMedia();
          cleanupPeerConnection();
          const pc = new RTCPeerConnection(RTC_CONFIG);
          pcRef.current = pc;

          if (stream) {
            for (const track of stream.getTracks()) {
              pc.addTrack(track, stream);
            }
          }

          pc.ontrack = (ev) => {
            if (remoteVideoRef.current && ev.streams[0]) {
              remoteVideoRef.current.srcObject = ev.streams[0];
            }
          };

          pc.onicecandidate = (ev) => {
            if (ev.candidate && ws.readyState === WebSocket.OPEN) {
              ws.send(
                JSON.stringify({
                  type: 'webrtc:ice',
                  roomId: msg.roomId,
                  payload: ev.candidate.toJSON(),
                })
              );
            }
          };

          if (msg.isInitiator) {
            const offer = await pc.createOffer();
            await pc.setLocalDescription(offer);
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(
                JSON.stringify({
                  type: 'webrtc:offer',
                  roomId: msg.roomId,
                  payload: offer,
                })
              );
            }
          }
          return;
        }

        if (msg.type === 'webrtc:offer' && msg.payload && msg.roomId) {
          if (!pcRef.current) return;
          await pcRef.current.setRemoteDescription(
            new RTCSessionDescription(msg.payload as RTCSessionDescriptionInit)
          );
          const answer = await pcRef.current.createAnswer();
          await pcRef.current.setLocalDescription(answer);
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(
              JSON.stringify({
                type: 'webrtc:answer',
                roomId: msg.roomId,
                payload: answer,
              })
            );
          }
          return;
        }

        if (msg.type === 'webrtc:answer' && msg.payload) {
          if (!pcRef.current) return;
          await pcRef.current.setRemoteDescription(
            new RTCSessionDescription(msg.payload as RTCSessionDescriptionInit)
          );
          return;
        }

        if (msg.type === 'webrtc:ice' && msg.payload) {
          if (!pcRef.current) return;
          await pcRef.current.addIceCandidate(
            new RTCIceCandidate(msg.payload as RTCIceCandidateInit)
          );
          return;
        }

        if (msg.type === 'call:chat' && msg.text) {
          setChatMessages((prev) => [
            ...prev,
            { id: `${Date.now()}_${Math.random()}`, sender: 'peer', text: msg.text! },
          ]);
          return;
        }

        if (msg.type === 'call:ended' || msg.type === 'call:terminated_moderation') {
          cleanupPeerConnection();
          setCallState('idle');
          setRoomId(null);
          setPeer(null);
          setStatusNotice(
            msg.type === 'call:terminated_moderation'
              ? 'Call terminated immediately by AI Safety Moderation.'
              : 'Video call ended.'
          );
        }
      } catch (err) {
        console.error('VideoCallStudio WS error:', err);
      }
    };

    ws.addEventListener('message', handleMessage);
    return () => ws.removeEventListener('message', handleMessage);
  }, [ws]);

  // Periodic AI frame scan during active video call
  useEffect(() => {
    if (callState !== 'connected' || !cameraOn) return;
    const timer = window.setInterval(() => {
      void runAiModerationScan();
    }, 15000);
    return () => window.clearInterval(timer);
  }, [callState, cameraOn]);

  async function startRandomMatch() {
    if (isUnder12 || isSuspended) return;
    await ensureLocalMedia();
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      setStatusNotice('Connecting to matchmaking socket... please try again in a second.');
      return;
    }
    ws.send(JSON.stringify({ type: 'call:join_queue', filter: genderFilter }));
  }

  function cancelQueue() {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'call:leave_queue' }));
    }
    setCallState('idle');
    setStatusNotice(null);
  }

  function endCall() {
    if (ws && ws.readyState === WebSocket.OPEN && roomId) {
      ws.send(JSON.stringify({ type: 'call:end', roomId }));
    }
    cleanupPeerConnection();
    setCallState('idle');
    setRoomId(null);
    setPeer(null);
    setStatusNotice('Call ended.');
  }

  function toggleCamera() {
    const next = !cameraOn;
    setCameraOn(next);
    if (localStreamRef.current) {
      for (const track of localStreamRef.current.getVideoTracks()) {
        track.enabled = next;
      }
    }
  }

  function toggleMic() {
    const next = !micOn;
    setMicOn(next);
    if (localStreamRef.current) {
      for (const track of localStreamRef.current.getAudioTracks()) {
        track.enabled = next;
      }
    }
  }

  function captureLocalFrameBase64(): string | undefined {
    const video = localVideoRef.current;
    if (!video || video.readyState < 2 || !cameraOn) return undefined;
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 240;
    const ctx = canvas.getContext('2d');
    if (!ctx) return undefined;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.7);
  }

  async function runAiModerationScan(explicitText?: string) {
    setAiScanning(true);
    try {
      const frameBase64 = captureLocalFrameBase64();
      const textSnippet = explicitText ?? (safetyTestInput.trim() || undefined);
      if (!frameBase64 && !textSnippet) {
        setStatusNotice('Turn on camera preview or enter a chat message to run an AI moderation scan.');
        setAiScanning(false);
        return;
      }
      const res = await api.analyzeModeration({
        frameBase64,
        textSnippet,
        roomId: roomIdRef.current || undefined,
      });
      setAiStatus(res.result);
      onUserUpdated(res.user);
      if (res.result.isViolation) {
        cleanupPeerConnection();
        setCallState('idle');
        setRoomId(null);
        setPeer(null);
        setStatusNotice(
          'AI moderation detected a violation. Call ended and account suspension is scheduled within 24 hours.'
        );
      }
    } catch (err) {
      setStatusNotice(err instanceof Error ? err.message : 'AI moderation check failed');
    } finally {
      setAiScanning(false);
    }
  }

  async function handleSendCallChat(e: React.FormEvent) {
    e.preventDefault();
    const text = chatInput.trim();
    if (!text) return;
    setChatInput('');
    setChatMessages((prev) => [
      ...prev,
      { id: `${Date.now()}`, sender: 'you', text },
    ]);
    if (ws && ws.readyState === WebSocket.OPEN && roomId) {
      ws.send(JSON.stringify({ type: 'call:chat', roomId, text }));
    }
    // Live AI scan on chat messages during call
    void runAiModerationScan(text);
  }

  if (isUnder12) {
    return (
      <div className="bg-[#FBF9F4] border border-[#E8DEC5] rounded-2xl p-8 max-w-2xl mx-auto text-center space-y-4">
        <div className="w-14 h-14 rounded-full bg-white border border-[#E8DEC5] flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6 text-[#997312]" />
        </div>
        <h2 className="font-display text-3xl font-semibold text-[#181510]">
          12+ Age Restriction Active
        </h2>
        <p className="text-sm text-[#6C6352] leading-relaxed">
          Random video calling on Black Gold is strictly restricted to members aged 12 and above.
          Your profile is registered as age {currentUser.age}. You still have full access to
          Dino Jump, Gold Rush Runner, and your Wallet.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {isSuspended && (
        <div className="p-5 rounded-2xl bg-[#FDF4F2] border border-[#E5B8B0] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-[#8B2E1E] font-semibold text-sm">
              <ShieldAlert className="w-4 h-4" />
              <span>Account Suspension Scheduled (Within 24 Hours)</span>
            </div>
            <p className="text-xs text-[#6B261B]">
              {currentUser.suspensionReason || 'AI moderation detected inappropriate call content.'}{' '}
              {currentUser.suspensionDeadlineAt &&
                `Full suspension takes effect by ${new Date(currentUser.suspensionDeadlineAt).toLocaleString()}.`}
            </p>
          </div>
          <button
            type="button"
            onClick={async () => {
              const res = await api.appealReset();
              onUserUpdated(res.user);
            }}
            className="px-4 py-2 text-xs font-semibold bg-white border border-[#E5B8B0] text-[#8B2E1E] rounded-lg hover:bg-[#FFF9F8] whitespace-nowrap shrink-0"
          >
            Submit Safety Appeal
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Video Stage */}
        <div className="lg:col-span-8 bg-white border border-[#E8DEC5] rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-[#E8DEC5] bg-[#FBF9F4] flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl font-semibold text-[#181510]">
                Random Video Lounge
              </h2>
              <p className="text-xs text-[#6C6352]">
                12+ Verified · WebRTC Peer-to-Peer · AI Moderated
              </p>
            </div>
            <div className="text-xs text-[#6C6352] font-mono-num">
              {wsConnected ? 'Signaling Ready' : 'Reconnecting...'}
              {callState === 'queued' ? ` · Queue (${queueSize})` : ''}
            </div>
          </div>

          <div className="p-5 space-y-4">
            {/* Dual Video Canvas */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="relative aspect-[4/3] bg-[#FBF9F4] border border-[#E8DEC5] rounded-xl overflow-hidden flex items-center justify-center">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${cameraOn ? 'opacity-100' : 'opacity-0'}`}
                />
                {!cameraOn && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-xs text-[#6C6352]">
                    <VideoOff className="w-6 h-6 mb-1.5 text-[#997312]" />
                    <span>Camera Paused</span>
                  </div>
                )}
                <div className="absolute left-3 bottom-3 px-2.5 py-1 rounded-md bg-white/90 border border-[#E8DEC5] text-[11px] font-semibold text-[#181510]">
                  You (@{currentUser.handle})
                </div>
              </div>

              <div className="relative aspect-[4/3] bg-[#FBF9F4] border border-[#E8DEC5] rounded-xl overflow-hidden flex items-center justify-center">
                <video
                  ref={remoteVideoRef}
                  autoPlay
                  playsInline
                  className={`w-full h-full object-cover ${
                    callState === 'connected' ? 'opacity-100' : 'opacity-0'
                  }`}
                />
                {callState !== 'connected' && (
                  <div className="absolute inset-0 p-6 flex flex-col items-center justify-center text-center">
                    <Video className="w-7 h-7 text-[#C59B27] mb-2" />
                    <p className="text-sm font-semibold text-[#181510]">
                      {callState === 'queued'
                        ? 'Matching in Progress...'
                        : 'Ready for Random Call'}
                    </p>
                    <p className="text-xs text-[#6C6352] mt-1 max-w-xs">
                      {callState === 'queued'
                        ? 'Open another tab or invite a friend to connect instantaneously via WebRTC.'
                        : 'Select your preferred pre-call gender filter below and press Start Random Call.'}
                    </p>
                  </div>
                )}
                {peer && callState === 'connected' && (
                  <div className="absolute inset-x-3 bottom-3 flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-md bg-white/90 border border-[#E8DEC5] text-[11px] font-semibold text-[#181510]">
                      {peer.displayName} (@{peer.handle})
                    </span>
                    <button
                      type="button"
                      onClick={() => onOpenReportModal(peer, 'video_call')}
                      className="px-2.5 py-1 rounded-md bg-white/95 border border-[#E5B8B0] text-[11px] font-semibold text-[#8B2E1E] flex items-center gap-1"
                    >
                      <Flag className="w-3 h-3" />
                      <span>Report / Block</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {mediaError && (
              <div className="px-3.5 py-2.5 rounded-xl bg-[#FBF9F4] border border-[#E8DEC5] text-xs text-[#6C6352]">
                {mediaError}
              </div>
            )}

            {statusNotice && (
              <div className="px-3.5 py-2.5 rounded-xl bg-[#FBF9F4] border border-[#E8DEC5] text-xs font-medium text-[#181510]">
                {statusNotice}
              </div>
            )}

            {/* Pre-Call Gender Filter + Primary Call Controls */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2 border-t border-[#F0E9D6]">
              <div>
                <p className="text-[11px] font-semibold text-[#6C6352] mb-1.5">
                  Pre-Call Gender Filter
                </p>
                <div className="flex flex-wrap items-center gap-1 p-1 bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg">
                  {(
                    [
                      { id: 'all', label: 'All' },
                      { id: 'woman', label: 'Women' },
                      { id: 'man', label: 'Men' },
                      { id: 'non-binary', label: 'Non-Binary' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      disabled={callState !== 'idle'}
                      onClick={() => setGenderFilter(opt.id)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                        genderFilter === opt.id
                          ? 'bg-[#C59B27] text-white'
                          : 'text-[#6C6352] hover:text-[#181510] disabled:opacity-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    if (!localStreamRef.current) {
                      await ensureLocalMedia();
                    } else {
                      toggleCamera();
                    }
                  }}
                  aria-label="Toggle camera"
                  className="min-h-[44px] min-w-[44px] px-3 rounded-xl border border-[#E8DEC5] bg-white hover:border-[#C59B27] flex items-center justify-center text-[#181510]"
                >
                  {cameraOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4 text-[#8B2E1E]" />}
                </button>
                <button
                  type="button"
                  onClick={toggleMic}
                  aria-label="Toggle microphone"
                  className="min-h-[44px] min-w-[44px] px-3 rounded-xl border border-[#E8DEC5] bg-white hover:border-[#C59B27] flex items-center justify-center text-[#181510]"
                >
                  {micOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-[#8B2E1E]" />}
                </button>

                {callState === 'idle' && (
                  <button
                    type="button"
                    disabled={isSuspended}
                    onClick={startRandomMatch}
                    className="min-h-[44px] px-5 py-2.5 bg-[#181510] hover:bg-[#2C261D] text-white text-xs font-semibold rounded-xl flex items-center gap-2 whitespace-nowrap disabled:opacity-50"
                  >
                    <Camera className="w-4 h-4 text-[#D4AF37]" />
                    <span>Start Random Call</span>
                  </button>
                )}

                {callState === 'queued' && (
                  <button
                    type="button"
                    onClick={cancelQueue}
                    className="min-h-[44px] px-5 py-2.5 bg-[#8B2E1E] text-white text-xs font-semibold rounded-xl whitespace-nowrap"
                  >
                    Leave Queue
                  </button>
                )}

                {callState === 'connected' && (
                  <button
                    type="button"
                    onClick={endCall}
                    className="min-h-[44px] px-5 py-2.5 bg-[#8B2E1E] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <PhoneOff className="w-4 h-4" />
                    <span>End Call</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel: AI Safety Shield & Live Call Chat */}
        <div className="lg:col-span-4 space-y-5">
          <div className="bg-[#FBF9F4] border border-[#E8DEC5] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#C59B27]" />
                <h3 className="font-display text-xl font-semibold text-[#181510]">
                  AI Call Moderation
                </h3>
              </div>
              <Sparkles className="w-4 h-4 text-[#C59B27]" />
            </div>

            <p className="text-xs text-[#4D4436] leading-relaxed">
              Live video frames and call messages are screened automatically. Confirmed
              inappropriate content terminates the call and triggers account suspension within 24
              hours.
            </p>

            <div className="space-y-2.5 pt-2 border-t border-[#E8DEC5]">
              <label className="block text-[11px] font-semibold text-[#181510]">
                Run Live AI Safety Check (Camera Frame / Message)
              </label>
              <input
                type="text"
                value={safetyTestInput}
                onChange={(e) => setSafetyTestInput(e.target.value)}
                placeholder="Optional message snippet to screen..."
                className="w-full px-3 py-2 text-xs bg-white border border-[#E8DEC5] rounded-lg focus:outline-none focus:border-[#C59B27]"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={ensureLocalMedia}
                  className="flex-1 min-h-[40px] px-3 py-2 text-xs font-semibold bg-white border border-[#E8DEC5] hover:border-[#C59B27] rounded-lg text-[#181510]"
                >
                  Preview Camera
                </button>
                <button
                  type="button"
                  disabled={aiScanning || isSuspended}
                  onClick={() => runAiModerationScan()}
                  className="flex-1 min-h-[40px] px-3 py-2 text-xs font-semibold bg-[#C59B27] hover:bg-[#B0871B] text-white rounded-lg disabled:opacity-50"
                >
                  {aiScanning ? 'Scanning...' : 'Scan Now'}
                </button>
              </div>
            </div>

            {aiStatus && (
              <div
                className={`p-3 rounded-xl border text-xs space-y-1 ${
                  aiStatus.isViolation
                    ? 'bg-[#FDF4F2] border-[#E5B8B0] text-[#8B2E1E]'
                    : 'bg-white border-[#E8DEC5] text-[#181510]'
                }`}
              >
                <div className="flex items-center justify-between font-semibold">
                  <span>
                    {aiStatus.isViolation ? 'Violation Detected' : 'Safety Cleared'} ·{' '}
                    {aiStatus.category}
                  </span>
                  <span className="font-mono-num">
                    {Math.round(aiStatus.confidence * 100)}%
                  </span>
                </div>
                <p className="text-[11px] opacity-90">{aiStatus.reason}</p>
              </div>
            )}
          </div>

          {/* Call Text Chat */}
          <div className="bg-white border border-[#E8DEC5] rounded-2xl p-5 flex flex-col h-72">
            <h3 className="text-xs font-semibold text-[#181510] pb-2.5 border-b border-[#F0E9D6]">
              Call Chat (AI Screened)
            </h3>
            <div className="flex-1 overflow-y-auto py-3 space-y-2 text-xs">
              {chatMessages.length === 0 ? (
                <p className="text-[#6C6352] text-center mt-10">
                  Messages exchanged during active calls appear here.
                </p>
              ) : (
                chatMessages.map((m) => (
                  <div
                    key={m.id}
                    className={`flex ${m.sender === 'you' ? 'justify-end' : 'justify-start'}`}
                  >
                    <span
                      className={`px-3 py-1.5 rounded-xl max-w-[85%] ${
                        m.sender === 'you'
                          ? 'bg-[#181510] text-white'
                          : 'bg-[#FBF9F4] border border-[#E8DEC5] text-[#181510]'
                      }`}
                    >
                      {m.text}
                    </span>
                  </div>
                ))
              )}
            </div>
            <form onSubmit={handleSendCallChat} className="flex gap-2 pt-2 border-t border-[#F0E9D6]">
              <input
                type="text"
                disabled={callState !== 'connected'}
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder={callState === 'connected' ? 'Message peer...' : 'Connect to chat'}
                className="flex-1 px-3 py-2 text-xs bg-[#FBF9F4] border border-[#E8DEC5] rounded-lg focus:outline-none focus:border-[#C59B27] disabled:opacity-60"
              />
              <button
                type="submit"
                disabled={callState !== 'connected'}
                aria-label="Send call message"
                className="min-h-[38px] min-w-[38px] rounded-lg bg-[#181510] text-white flex items-center justify-center disabled:opacity-40"
              >
                <Send className="w-3.5 h-3.5 text-[#D4AF37]" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
